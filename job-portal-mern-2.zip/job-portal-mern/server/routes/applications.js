// ── routes/applications.js ────────────────────────────
const express = require('express');
const router = express.Router();
const { applyJob, getMyApplications, getJobApplications, updateApplicationStatus } = require('../controllers/companyController');
const { protect, authorize } = require('../middleware/auth');

router.post('/job/:jobId',          protect, applyJob);
router.get('/my',                   protect, getMyApplications);
router.get('/job/:jobId',           protect, authorize('employer', 'admin'), getJobApplications);
router.put('/:id/status',           protect, authorize('employer', 'admin'), updateApplicationStatus);

module.exports = router;
