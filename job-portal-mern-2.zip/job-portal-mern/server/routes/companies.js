// ── routes/companies.js ───────────────────────────────
const express = require('express');
const router = express.Router();
const { getCompanies, getCompany, createCompany, updateCompany } = require('../controllers/companyController');
const { protect, authorize } = require('../middleware/auth');

router.get('/',      getCompanies);
router.get('/:id',   getCompany);
router.post('/',     protect, authorize('employer', 'admin'), createCompany);
router.put('/:id',   protect, authorize('employer', 'admin'), updateCompany);

module.exports = router;
