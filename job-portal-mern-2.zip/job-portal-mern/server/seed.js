const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
dotenv.config();

const User = require('./models/User');
const Job  = require('./models/Job');
const { Company } = require('./models/Company');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/workflow_db';

const seedData = async () => {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to MongoDB');

  // Clear existing
  await User.deleteMany();
  await Job.deleteMany();
  await Company.deleteMany();
  console.log('Cleared existing data');

  // Create admin + employers
  const admin = await User.create({ name: 'Admin User',  email: 'admin@workflow.com',    password: 'admin123',    role: 'admin' });
  const emp1  = await User.create({ name: 'HR Google',   email: 'hr@google.com',          password: 'employer123', role: 'employer' });
  const emp2  = await User.create({ name: 'HR Stripe',   email: 'hr@stripe.com',          password: 'employer123', role: 'employer' });
  const emp3  = await User.create({ name: 'HR Notion',   email: 'hr@notion.com',          password: 'employer123', role: 'employer' });
  const seeker= await User.create({ name: 'Jane Seeker', email: 'jane@example.com',        password: 'seeker123',   role: 'jobseeker' });
  console.log('Users created');

  // Companies
  const [google, stripe, notion, vercel, airbnb, figma, shopify, linear] = await Company.create([
    { name: 'Google',   industry: 'Technology',     size: '5000+',    founded: 1998, rating: 4.8, logoColor: '#e8f0fb', logoText: '#185fa5', coverColor: '#1a73e8', location: 'Mountain View, CA', description: 'Building products that organise the world\'s information.', website: 'https://google.com', owner: emp1._id, isVerified: true },
    { name: 'Stripe',   industry: 'Fintech',        size: '1001-5000',founded: 2010, rating: 4.7, logoColor: '#faeeda', logoText: '#854f0b', coverColor: '#635BFF', location: 'Remote',            description: 'The economic infrastructure for the internet.',               website: 'https://stripe.com', owner: emp2._id, isVerified: true },
    { name: 'Notion',   industry: 'Productivity',   size: '201-1000', founded: 2016, rating: 4.6, logoColor: '#e8e4dc', logoText: '#4a4843', coverColor: '#191919', location: 'San Francisco, CA',  description: 'All-in-one workspace for notes, docs, and projects.',          website: 'https://notion.so',  owner: emp3._id, isVerified: true },
    { name: 'Vercel',   industry: 'Cloud / DevTools',size: '201-1000',founded: 2015, rating: 4.8, logoColor: '#e8e4dc', logoText: '#0f0e0c', coverColor: '#000000', location: 'Remote',            description: 'The platform for frontend developers.',                        website: 'https://vercel.com', owner: emp1._id, isVerified: true },
    { name: 'Airbnb',   industry: 'Travel',         size: '1001-5000',founded: 2008, rating: 4.5, logoColor: '#fcebeb', logoText: '#a32d2d', coverColor: '#FF5A5F', location: 'San Francisco, CA',  description: 'Belong anywhere.',                                             website: 'https://airbnb.com', owner: emp2._id, isVerified: true },
    { name: 'Figma',    industry: 'Design Tools',   size: '201-1000', founded: 2012, rating: 4.9, logoColor: '#eaf3de', logoText: '#2a5c12', coverColor: '#F24E1E', location: 'Remote',            description: 'Design, prototype, and collaborate in the browser.',           website: 'https://figma.com',  owner: emp3._id, isVerified: true },
    { name: 'Shopify',  industry: 'E-commerce',     size: '5000+',    founded: 2006, rating: 4.4, logoColor: '#eaf3de', logoText: '#2a5c12', coverColor: '#96bf48', location: 'Toronto / Remote',  description: 'Commerce platform powering 1.7M+ businesses.',                website: 'https://shopify.com',owner: emp1._id, isVerified: true },
    { name: 'Linear',   industry: 'Developer Tools',size: '11-50',    founded: 2019, rating: 4.9, logoColor: '#fcebeb', logoText: '#a32d2d', coverColor: '#5e6ad2', location: 'Remote',            description: 'The issue tracker for high-performance teams.',                 website: 'https://linear.app', owner: emp2._id, isVerified: true },
  ]);
  console.log('Companies created');

  // Jobs
  await Job.create([
    { title: 'Senior Product Designer',    company: google._id,  postedBy: emp1._id, location: 'Mountain View, CA', mode: 'Remote',  type: 'Full-time', experience: 'Senior',       domain: 'Design',      salaryMin: 60, salaryMax: 90,  salaryDisplay: '₹60–90L',  currency: '₹', tags: ['Figma','Design Systems','User Research'], description: 'Shape the next generation of Google\'s consumer products.', requirements: ['5+ years product design','Expert Figma proficiency','Design systems experience'], perks: ['Equity package','Health & dental','$5k learning budget'], featured: true, urgent: false },
    { title: 'Lead UX Designer',           company: stripe._id,  postedBy: emp2._id, location: 'Remote',            mode: 'Remote',  type: 'Full-time', experience: 'Lead / Principal',domain: 'Design',   salaryMin: 75, salaryMax: 110, salaryDisplay: '₹75–110L', currency: '₹', tags: ['B2B SaaS','Developer Tools','Motion Design'], description: 'Own the experience for our developer-facing surfaces.', requirements: ['7+ years UX design','Lead role experience','Developer product design'], perks: ['Top-of-market comp','$500/mo stipend','Unlimited PTO'], featured: true, urgent: true },
    { title: 'Product Designer — Growth',  company: notion._id,  postedBy: emp3._id, location: 'San Francisco, CA', mode: 'Hybrid',  type: 'Full-time', experience: 'Mid-senior',    domain: 'Design',      salaryMin: 55, salaryMax: 80,  salaryDisplay: '₹55–80L',  currency: '₹', tags: ['A/B Testing','Activation','Funnel Optimization'], description: 'Improve activation and retention across our product.', requirements: ['3–6 years product design','Growth design experience','Analytics comfort'], perks: ['Equity','Quarterly retreats','$1500 learning stipend'], featured: false, urgent: false },
    { title: 'Staff Frontend Engineer',    company: vercel._id,  postedBy: emp1._id, location: 'Remote',            mode: 'Remote',  type: 'Full-time', experience: 'Senior',        domain: 'Engineering', salaryMin: 90, salaryMax: 130, salaryDisplay: '₹90–130L', currency: '₹', tags: ['React','Next.js','TypeScript','Performance'], description: 'Build the world\'s fastest deployment platform.', requirements: ['8+ years frontend','Expert React/TypeScript','Next.js expertise'], perks: ['Remote-first','Generous equity','Home office budget'], featured: true, urgent: false },
    { title: 'Senior Data Scientist',      company: airbnb._id,  postedBy: emp2._id, location: 'San Francisco, CA', mode: 'Hybrid',  type: 'Full-time', experience: 'Senior',        domain: 'Data',        salaryMin: 80, salaryMax: 120, salaryDisplay: '₹80–120L', currency: '₹', tags: ['Python','SQL','Causal Inference','ML Modeling'], description: 'Build models shaping pricing, search ranking, and trust.', requirements: ['5+ years data science','Strong statistics','Python & SQL proficiency'], perks: ['$2k travel credit','RSUs + bonus','Flexible hybrid'], featured: false, urgent: true },
    { title: 'Product Manager — Platform', company: figma._id,   postedBy: emp3._id, location: 'Remote',            mode: 'Remote',  type: 'Full-time', experience: 'Mid-senior',    domain: 'Product',     salaryMin: 70, salaryMax: 100, salaryDisplay: '₹70–100L', currency: '₹', tags: ['APIs','Developer Platform','Plugin Ecosystem'], description: 'Grow our plugin ecosystem and developer platform strategy.', requirements: ['4+ years PM','Technical API background','Developer ecosystem experience'], perks: ['Fully remote','Annual offsite','Top-tier health'], featured: false, urgent: false },
    { title: 'Growth Marketing Manager',   company: shopify._id, postedBy: emp1._id, location: 'Toronto / Remote',  mode: 'Remote',  type: 'Full-time', experience: 'Mid-senior',    domain: 'Marketing',   salaryMin: 50, salaryMax: 75,  salaryDisplay: '₹50–75L',  currency: '₹', tags: ['Paid Acquisition','SEO','Email Marketing','Analytics'], description: 'Own merchant acquisition across paid, organic, and email channels.', requirements: ['3–5 years growth marketing','Google/Meta ads hands-on','Analytics skills'], perks: ['Remote-first','Stock options','Generous parental leave'], featured: false, urgent: false },
    { title: 'UI/UX Designer — Mobile',    company: linear._id,  postedBy: emp2._id, location: 'Remote',            mode: 'Remote',  type: 'Full-time', experience: 'Senior',        domain: 'Design',      salaryMin: 45, salaryMax: 70,  salaryDisplay: '₹45–70L',  currency: '₹', tags: ['iOS','Android','React Native','Motion Design'], description: 'Craft best-in-class iOS and Android experiences.', requirements: ['4+ years mobile design','iOS/Android guidelines expertise','Motion design sensibility'], perks: ['Top-tier equity','Async-first culture','Annual retreat'], featured: false, urgent: false },
  ]);
  console.log('Jobs created');
  console.log('\n✅ Seed complete!');
  console.log('📧 Test logins:');
  console.log('   admin@workflow.com    / admin123');
  console.log('   hr@google.com         / employer123');
  console.log('   jane@example.com      / seeker123');
  mongoose.disconnect();
};

seedData().catch(err => { console.error(err); mongoose.disconnect(); });
