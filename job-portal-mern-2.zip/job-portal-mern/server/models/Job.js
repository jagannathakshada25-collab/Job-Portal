const mongoose = require('mongoose');

const JobSchema = new mongoose.Schema({
  title:       { type: String, required: true, trim: true },
  company:     { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true },
  postedBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  location:    { type: String, required: true },
  mode:        { type: String, enum: ['Remote', 'Hybrid', 'On-site'], required: true },
  type:        { type: String, enum: ['Full-time', 'Part-time', 'Contract', 'Freelance', 'Internship'], required: true },
  experience:  { type: String, enum: ['Entry level', 'Mid-senior', 'Senior', 'Lead / Principal', 'Director+'], required: true },
  domain:      { type: String, enum: ['Design', 'Engineering', 'Product', 'Data', 'Marketing', 'Finance', 'Operations', 'Sales', 'HR'], required: true },
  salaryMin:   { type: Number, default: 0 },
  salaryMax:   { type: Number, default: 0 },
  salaryDisplay: { type: String, default: '' },
  currency:    { type: String, default: '₹', enum: ['₹', '$', '€', '£'] },
  description: { type: String, required: true },
  requirements: [{ type: String }],
  perks:       [{ type: String }],
  tags:        [{ type: String }],
  featured:    { type: Boolean, default: false },
  urgent:      { type: Boolean, default: false },
  isActive:    { type: Boolean, default: true },
  applicationsCount: { type: Number, default: 0 },
  views:       { type: Number, default: 0 },
  expiresAt:   { type: Date, default: () => new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) }
}, { timestamps: true });

// Text search index
JobSchema.index({ title: 'text', description: 'text', tags: 'text' });

// Virtual for company logo (populated)
JobSchema.virtual('companyDetails', { ref: 'Company', localField: 'company', foreignField: '_id', justOne: true });

module.exports = mongoose.model('Job', JobSchema);
