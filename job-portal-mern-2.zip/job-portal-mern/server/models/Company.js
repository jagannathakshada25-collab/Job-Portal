const mongoose = require('mongoose');

// ── Company Model ─────────────────────────────────────
const CompanySchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true, unique: true },
  slug:        { type: String, unique: true, lowercase: true },
  description: { type: String, default: '' },
  industry:    { type: String, required: true },
  size:        { type: String, enum: ['1-10', '11-50', '51-200', '201-1000', '1001-5000', '5000+'], default: '51-200' },
  founded:     { type: Number },
  website:     { type: String, default: '' },
  logo:        { type: String, default: '' },
  coverImage:  { type: String, default: '' },
  logoColor:   { type: String, default: '#e8f0fb' },
  logoText:    { type: String, default: '#185fa5' },
  coverColor:  { type: String, default: '#1a73e8' },
  location:    { type: String, default: '' },
  rating:      { type: Number, default: 0, min: 0, max: 5 },
  reviewCount: { type: Number, default: 0 },
  linkedin:    { type: String, default: '' },
  twitter:     { type: String, default: '' },
  owner:       { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isVerified:  { type: Boolean, default: false },
  isActive:    { type: Boolean, default: true }
}, { timestamps: true });

CompanySchema.pre('save', function (next) {
  if (this.isModified('name')) {
    this.slug = this.name.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');
  }
  next();
});

// ── Application Model ─────────────────────────────────
const ApplicationSchema = new mongoose.Schema({
  job:        { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
  applicant:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  company:    { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true },
  fullName:   { type: String, required: true },
  email:      { type: String, required: true },
  phone:      { type: String, default: '' },
  linkedin:   { type: String, default: '' },
  coverLetter:{ type: String, default: '' },
  resume:     { type: String, default: '' },
  status: {
    type: String,
    enum: ['pending', 'reviewing', 'shortlisted', 'interviewed', 'offered', 'rejected', 'withdrawn'],
    default: 'pending'
  },
  notes:      { type: String, default: '' }
}, { timestamps: true });

// Prevent duplicate applications
ApplicationSchema.index({ job: 1, applicant: 1 }, { unique: true });

module.exports.Company     = mongoose.model('Company',     CompanySchema);
module.exports.Application = mongoose.model('Application', ApplicationSchema);
