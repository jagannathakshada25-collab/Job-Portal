const { Company, Application } = require('../models/Company');
const Job = require('../models/Job');

// ── COMPANIES ──────────────────────────────────────────

exports.getCompanies = async (req, res) => {
  try {
    const { q, industry, page = 1, limit = 12 } = req.query;
    const filter = { isActive: true };
    if (q)        filter.name     = { $regex: q, $options: 'i' };
    if (industry) filter.industry = industry;
    const skip = (Number(page) - 1) * Number(limit);
    const [companies, total] = await Promise.all([
      Company.find(filter).sort({ rating: -1 }).skip(skip).limit(Number(limit)),
      Company.countDocuments(filter)
    ]);
    // Attach openJobs count
    const companiesWithJobs = await Promise.all(companies.map(async c => {
      const openJobs = await Job.countDocuments({ company: c._id, isActive: true });
      return { ...c.toObject(), openJobs };
    }));
    res.json({ success: true, companies: companiesWithJobs, total, totalPages: Math.ceil(total / Number(limit)) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getCompany = async (req, res) => {
  try {
    const company = await Company.findOne({ $or: [{ _id: req.params.id }, { slug: req.params.id }] })
      .populate('owner', 'name email');
    if (!company) return res.status(404).json({ success: false, message: 'Company not found' });
    const openJobs = await Job.countDocuments({ company: company._id, isActive: true });
    const jobs = await Job.find({ company: company._id, isActive: true }).sort({ createdAt: -1 }).limit(6);
    res.json({ success: true, company: { ...company.toObject(), openJobs }, jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.createCompany = async (req, res) => {
  try {
    const company = await Company.create({ ...req.body, owner: req.user.id });
    const User = require('../models/User');
    await User.findByIdAndUpdate(req.user.id, { company: company._id });
    res.status(201).json({ success: true, company });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

exports.updateCompany = async (req, res) => {
  try {
    const company = await Company.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!company) return res.status(404).json({ success: false, message: 'Company not found' });
    res.json({ success: true, company });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// ── APPLICATIONS ───────────────────────────────────────

exports.applyJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.jobId).populate('company');
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });

    const exists = await Application.findOne({ job: job._id, applicant: req.user.id });
    if (exists) return res.status(400).json({ success: false, message: 'Already applied to this job' });

    const application = await Application.create({
      job: job._id,
      applicant: req.user.id,
      company: job.company._id,
      ...req.body
    });
    await Job.findByIdAndUpdate(job._id, { $inc: { applicationsCount: 1 } });
    res.status(201).json({ success: true, application });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

exports.getMyApplications = async (req, res) => {
  try {
    const apps = await Application.find({ applicant: req.user.id })
      .populate('job', 'title salaryDisplay mode type')
      .populate('company', 'name logo logoColor logoText')
      .sort({ createdAt: -1 });
    res.json({ success: true, applications: apps });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getJobApplications = async (req, res) => {
  try {
    const apps = await Application.find({ job: req.params.jobId })
      .populate('applicant', 'name email avatar headline skills')
      .sort({ createdAt: -1 });
    res.json({ success: true, applications: apps });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateApplicationStatus = async (req, res) => {
  try {
    const app = await Application.findByIdAndUpdate(
      req.params.id, { status: req.body.status, notes: req.body.notes }, { new: true }
    );
    res.json({ success: true, application: app });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};
