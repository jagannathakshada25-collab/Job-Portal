const Job = require('../models/Job');
const { Company } = require('../models/Company');

// @GET /api/jobs  – list with filters, search, pagination
exports.getJobs = async (req, res) => {
  try {
    const {
      q, location, mode, type, experience, domain, size,
      minSalary, featured, urgent, page = 1, limit = 8, sort = 'relevant'
    } = req.query;

    const filter = { isActive: true, expiresAt: { $gte: new Date() } };

    if (q) filter.$text = { $search: q };
    if (mode)       filter.mode = mode;
    if (type)       filter.type = type;
    if (experience) filter.experience = experience;
    if (domain)     filter.domain = domain;
    if (minSalary)  filter.salaryMax = { $gte: Number(minSalary) };
    if (featured === 'true') filter.featured = true;
    if (urgent === 'true')   filter.urgent   = true;

    // Location search across Job + Company
    let locationFilter = null;
    if (location) {
      locationFilter = { location: { $regex: location, $options: 'i' } };
    }

    const sortMap = {
      relevant:  { featured: -1, createdAt: -1 },
      newest:    { createdAt: -1 },
      salary:    { salaryMax: -1 },
      oldest:    { createdAt: 1 }
    };
    const sortQuery = sortMap[sort] || sortMap.relevant;

    const skip = (Number(page) - 1) * Number(limit);

    let query = Job.find(filter)
      .populate('company', 'name logo logoColor logoText industry size rating location')
      .sort(sortQuery)
      .skip(skip)
      .limit(Number(limit));

    const [jobs, total] = await Promise.all([query, Job.countDocuments(filter)]);

    // Increment views for first page
    if (page === '1' && jobs.length > 0) {
      await Job.updateMany({ _id: { $in: jobs.map(j => j._id) } }, { $inc: { views: 1 } });
    }

    res.json({
      success: true,
      count: jobs.length,
      total,
      totalPages: Math.ceil(total / Number(limit)),
      currentPage: Number(page),
      jobs
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @GET /api/jobs/:id
exports.getJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id)
      .populate('company', 'name logo logoColor logoText industry size rating location website description')
      .populate('postedBy', 'name avatar');
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    res.json({ success: true, job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @POST /api/jobs  – employer creates job
exports.createJob = async (req, res) => {
  try {
    const job = await Job.create({ ...req.body, postedBy: req.user.id });
    await job.populate('company', 'name logo logoColor logoText');
    res.status(201).json({ success: true, job });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// @PUT /api/jobs/:id
exports.updateJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    if (job.postedBy.toString() !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized' });
    const updated = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json({ success: true, job: updated });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
};

// @DELETE /api/jobs/:id
exports.deleteJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ success: false, message: 'Job not found' });
    if (job.postedBy.toString() !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized' });
    await job.deleteOne();
    res.json({ success: true, message: 'Job deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @POST /api/jobs/:id/save  – toggle save
exports.toggleSaveJob = async (req, res) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user.id);
    const jobId = req.params.id;
    const isSaved = user.savedJobs.includes(jobId);
    if (isSaved) user.savedJobs.pull(jobId);
    else user.savedJobs.push(jobId);
    await user.save();
    res.json({ success: true, saved: !isSaved, savedJobs: user.savedJobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
