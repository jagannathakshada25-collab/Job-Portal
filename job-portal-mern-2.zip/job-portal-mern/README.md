# WorkFlow — MERN Stack Job Portal

A full-stack job portal built with **MongoDB, Express.js, React.js, and Node.js**.

---

## 🗂️ Project Structure

```
job-portal-mern/
├── package.json               ← Root monorepo (runs both concurrently)
│
├── server/                    ← Express + MongoDB Backend
│   ├── index.js               ← App entry point
│   ├── .env.example           ← Copy to .env and fill in values
│   ├── seed.js                ← Seed sample data into MongoDB
│   ├── models/
│   │   ├── User.js            ← User schema (jobseeker/employer/admin)
│   │   ├── Job.js             ← Job listing schema
│   │   └── Company.js         ← Company + Application schemas
│   ├── controllers/
│   │   ├── authController.js  ← Register, login, me, update profile
│   │   ├── jobController.js   ← CRUD jobs + toggle save
│   │   └── companyController.js ← Companies + applications
│   ├── routes/
│   │   ├── auth.js
│   │   ├── jobs.js
│   │   ├── companies.js
│   │   ├── applications.js
│   │   └── users.js
│   └── middleware/
│       └── auth.js            ← JWT protect + role authorize
│
└── client/                    ← React Frontend
    ├── public/index.html
    └── src/
        ├── App.js             ← All routes defined here
        ├── index.js           ← React entry point
        ├── context/
        │   └── AuthContext.jsx ← Global auth state (login/logout/save)
        ├── utils/
        │   └── api.js         ← Axios instance with JWT interceptor
        ├── styles/
        │   └── globals.css    ← CSS variables, reset, animations
        ├── components/
        │   ├── common/
        │   │   ├── Navbar.jsx + Navbar.css
        │   │   └── Common.jsx (Footer, Spinner, ProtectedRoute, EmptyState)
        │   └── jobs/
        │       ├── JobCard.jsx + JobCard.css
        │       ├── JobFilters.jsx + JobFilters.css
        │       └── JobDrawer.jsx + JobDrawer.css
        └── pages/
            ├── HomePage.jsx + HomePage.css
            ├── JobsPage.jsx + JobsPage.css
            ├── CompaniesPage.jsx + CompaniesPage.css
            ├── AuthPages.jsx + AuthPages.css  (Login + Register)
            ├── PostJobPage.jsx + PostJobPage.css
            ├── UserPages.jsx   (Profile, Applications, SavedJobs, Dashboard)
            └── InfoPages.jsx   (Salaries, Blog)
```

---

## 🚀 Getting Started

### Prerequisites
- **Node.js** v18+ — https://nodejs.org
- **MongoDB** — either local install or [MongoDB Atlas](https://cloud.mongodb.com) (free tier)

---

### 1. Clone / unzip the project

```bash
unzip job-portal-mern.zip
cd job-portal-mern
```

---

### 2. Configure environment variables

```bash
cd server
cp .env.example .env
```

Edit `server/.env`:

```env
MONGO_URI=mongodb://localhost:27017/workflow_db
# Or Atlas: mongodb+srv://<user>:<pass>@cluster.mongodb.net/workflow_db

JWT_SECRET=your_super_secret_key_here
JWT_EXPIRE=7d
PORT=5000
CLIENT_URL=http://localhost:3000
```

---

### 3. Install all dependencies

```bash
# From root folder
npm run install-all
```

Or manually:
```bash
cd server && npm install
cd ../client && npm install
```

---

### 4. Seed sample data (optional but recommended)

```bash
cd server
node seed.js
```

This creates:
- 8 companies (Google, Stripe, Notion, Vercel, Airbnb, Figma, Shopify, Linear)
- 8 realistic job listings
- Test user accounts:

| Email | Password | Role |
|-------|----------|------|
| admin@workflow.com | admin123 | Admin |
| hr@google.com | employer123 | Employer |
| jane@example.com | seeker123 | Job Seeker |

---

### 5. Run the full stack

```bash
# From root folder — starts both server and client
npm run dev
```

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/api
- **Health check**: http://localhost:5000/api/health

---

## 🔌 API Endpoints

### Auth
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/auth/register` | Public | Register new user |
| POST | `/api/auth/login` | Public | Login, returns JWT |
| GET | `/api/auth/me` | Private | Get current user |
| PUT | `/api/auth/update-profile` | Private | Update profile |
| PUT | `/api/auth/change-password` | Private | Change password |

### Jobs
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/jobs` | Public | List jobs (with filters) |
| GET | `/api/jobs/:id` | Public | Get single job |
| POST | `/api/jobs` | Employer | Create job |
| PUT | `/api/jobs/:id` | Employer | Update job |
| DELETE | `/api/jobs/:id` | Employer | Delete job |
| POST | `/api/jobs/:id/save` | Private | Toggle save job |

**Job Filter Query Params:**
```
?q=designer&location=remote&mode=Remote&type=Full-time
&experience=Senior&domain=Design&minSalary=60
&sort=relevant&page=1&limit=8
```

### Companies
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/companies` | Public | List companies |
| GET | `/api/companies/:id` | Public | Get company + jobs |
| POST | `/api/companies` | Employer | Create company |
| PUT | `/api/companies/:id` | Employer | Update company |

### Applications
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/applications/job/:jobId` | Private | Apply for job |
| GET | `/api/applications/my` | Private | My applications |
| GET | `/api/applications/job/:jobId` | Employer | Job's applicants |
| PUT | `/api/applications/:id/status` | Employer | Update status |

---

## 🛠️ Tech Stack

### Backend
| Package | Purpose |
|---------|---------|
| express | Web framework |
| mongoose | MongoDB ODM |
| jsonwebtoken | JWT authentication |
| bcryptjs | Password hashing |
| dotenv | Environment variables |
| cors | Cross-origin requests |
| express-validator | Input validation |
| nodemon | Dev auto-reload |

### Frontend
| Package | Purpose |
|---------|---------|
| react 18 | UI library |
| react-router-dom v6 | Client-side routing |
| axios | HTTP client |
| react-toastify | Toast notifications |
| Google Fonts | DM Sans + DM Serif Display |

---

## 🌟 Features

### For Job Seekers
- Browse and search 8+ job categories
- Real-time multi-criteria filtering (type, mode, experience, salary, domain)
- Save/bookmark jobs (persisted in MongoDB)
- Slide-in job detail drawer with inline application form
- Track application status (pending → shortlisted → offered)
- Profile page with skills, links, headline

### For Employers
- Post job listings with rich description, requirements, perks
- Mark jobs as featured or urgent
- Employer dashboard to manage listings
- View applicants per job
- Update application status

### Technical Highlights
- JWT authentication with `Authorization: Bearer <token>` headers
- Role-based access control (jobseeker / employer / admin)
- Protected React routes with `ProtectedRoute` component
- Global `AuthContext` managing user state + saved jobs
- Axios interceptor auto-attaches JWT to every request
- Debounced real-time search (300ms delay)
- MongoDB text indexes for full-text job search
- Responsive design — mobile, tablet, desktop

---

## 📦 Build for Production

```bash
# Build React client
npm run build

# Serve from Express (add static serving to server/index.js)
# The build folder goes into client/build/
```

---

## 🔧 Troubleshooting

**MongoDB connection refused**
→ Make sure MongoDB is running: `mongod` or use Atlas URI

**Port 5000 already in use**
→ Change `PORT=5001` in `server/.env`

**CORS errors**
→ Set `CLIENT_URL=http://localhost:3000` in `server/.env`

**JWT errors after seeding**
→ Make sure `JWT_SECRET` is set in `.env`
