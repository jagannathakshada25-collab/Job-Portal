import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'react-toastify';
import './JobCard.css';

const TAG_STYLES = {
  Remote:  { bg: '#eaf3de', color: '#2a5c12', border: '#c0dd97' },
  Hybrid:  { bg: '#e8f0fb', color: '#18469a', border: '#b5d4f4' },
  'On-site':{ bg: '#f2efe9', color: '#4a4843', border: '#e8e4dc' },
  Urgent:  { bg: '#fcebeb', color: '#8f2020', border: '#f09595' },
  New:     { bg: '#faeeda', color: '#7a4208', border: '#fac775' },
};

const Tag = ({ label }) => {
  const s = TAG_STYLES[label] || { bg: 'var(--surface-2)', color: 'var(--ink-3)', border: 'var(--border)' };
  return (
    <span className="job-tag" style={{ background: s.bg, color: s.color, borderColor: s.border }}>
      {label}
    </span>
  );
};

const timeAgo = (dateStr) => {
  const diff = Date.now() - new Date(dateStr);
  const h = Math.floor(diff / 3600000);
  if (h < 1)  return 'Just now';
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return `${Math.floor(d / 30)}mo ago`;
};

const JobCard = ({ job, onOpen, delay = 0 }) => {
  const { isAuth, isJobSaved, toggleSave } = useAuth();
  const navigate = useNavigate();
  const saved = isJobSaved(job._id);
  const co = job.company || {};

  const handleSave = async (e) => {
    e.stopPropagation();
    if (!isAuth) { toast.info('Sign in to save jobs'); navigate('/login'); return; }
    try {
      const wasSaved = await toggleSave(job._id);
      toast.success(wasSaved ? 'Job saved!' : 'Removed from saved jobs');
    } catch {
      toast.error('Could not save job');
    }
  };

  const handleApply = (e) => {
    e.stopPropagation();
    if (onOpen) onOpen(job);
    else navigate(`/jobs/${job._id}`);
  };

  return (
    <article
      className={`job-card ${job.featured ? 'featured' : ''} ${saved ? 'saved' : ''}`}
      style={{ animationDelay: `${delay}s` }}
      onClick={() => onOpen ? onOpen(job) : navigate(`/jobs/${job._id}`)}
      tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && (onOpen ? onOpen(job) : navigate(`/jobs/${job._id}`))}
    >
      {job.featured && <div className="card-featured-badge">Featured</div>}

      <div className="card-top">
        <div className="co-logo" style={{ background: co.logoColor || '#e8f0fb', color: co.logoText || '#185fa5' }}>
          {(co.name || 'C')[0]}
        </div>
        <div className="card-info">
          <div className="card-title">{job.title}</div>
          <div className="card-company"><strong>{co.name}</strong> · {job.location}</div>
        </div>
        <div className="salary-pill">{job.salaryDisplay || `${job.currency || '₹'}${job.salaryMin}–${job.salaryMax}L`}</div>
      </div>

      <div className="card-tags">
        <Tag label={job.mode} />
        {job.urgent && <Tag label="Urgent" />}
        {(Date.now() - new Date(job.createdAt)) < 86400000 * 3 && <Tag label="New" />}
        {(job.tags || []).slice(0, 3).map(t => <Tag key={t} label={t} />)}
      </div>

      <div className="card-footer">
        <div className="card-meta">
          <span className="meta-item">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            {timeAgo(job.createdAt)}
          </span>
          <span className="meta-item">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            {job.applicationsCount || 0}
          </span>
          {co.rating > 0 && (
            <span className="meta-item">
              <svg fill="currentColor" viewBox="0 0 24 24" style={{color:'#f59e0b'}}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              {co.rating}
            </span>
          )}
        </div>
        <div className="card-actions" onClick={e => e.stopPropagation()}>
          <button className={`btn-save ${saved ? 'saved' : ''}`} onClick={handleSave} aria-label={saved ? 'Unsave' : 'Save'}>
            <svg width="14" height="14" fill={saved ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <button className="btn-apply" onClick={handleApply}>View &amp; Apply</button>
        </div>
      </div>
    </article>
  );
};

export default JobCard;
