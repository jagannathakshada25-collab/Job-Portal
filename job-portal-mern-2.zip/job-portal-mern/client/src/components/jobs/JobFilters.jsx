import React from 'react';
import './JobFilters.css';

const FILTERS = {
  type:   ['Full-time','Part-time','Contract','Freelance','Internship'],
  mode:   ['Remote','Hybrid','On-site'],
  exp:    ['Entry level','Mid-senior','Senior','Lead / Principal','Director+'],
  domain: ['Design','Engineering','Product','Data','Marketing','Finance','Operations'],
  size:   ['1-10','11-50','51-200','201-1000','1001-5000','5000+'],
};

const Chip = ({ label, active, onClick }) => (
  <button className={`chip ${active ? 'active' : ''}`} onClick={onClick} type="button">{label}</button>
);

const JobFilters = ({ filters, onChange, onClear }) => {
  const toggle = (key, val) => {
    const cur = filters[key] || '';
    onChange({ [key]: cur === val ? '' : val });
  };

  return (
    <aside className="job-filters">
      <div className="filters-header">
        <span className="filters-title">Filters</span>
        <button className="clear-btn" onClick={onClear}>Clear all</button>
      </div>

      {[
        { key: 'type',   label: 'Job type',       opts: FILTERS.type },
        { key: 'mode',   label: 'Work mode',       opts: FILTERS.mode },
        { key: 'experience', label: 'Experience',  opts: FILTERS.exp },
        { key: 'domain', label: 'Domain',          opts: FILTERS.domain },
      ].map(({ key, label, opts }) => (
        <div key={key} className="filter-section">
          <div className="filter-label">{label}</div>
          <div className="chip-group">
            {opts.map(o => (
              <Chip key={o} label={o} active={filters[key] === o} onClick={() => toggle(key, o)} />
            ))}
          </div>
          <div className="filter-divider" />
        </div>
      ))}

      <div className="filter-section">
        <div className="filter-label">Minimum salary (LPA)</div>
        <div className="range-wrap">
          <input
            type="range" min="0" max="200" step="5"
            value={filters.minSalary || 0}
            onChange={e => onChange({ minSalary: e.target.value })}
            className="range-slider"
          />
          <div className="range-labels">
            <span>₹0L</span>
            <span className="range-val">₹{filters.minSalary || 0}L+</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default JobFilters;
