import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import api from '../../utils/api';
import './JobDrawer.css';

const InfoBox = ({ label, value }) => (
  <div className="info-box">
    <div className="info-box-label">{label}</div>
    <div className="info-box-val">{value}</div>
  </div>
);

const JobDrawer = ({ job, onClose }) => {
  const { isAuth, isJobSaved, toggleSave } = useAuth();
  const navigate = useNavigate();
  const [applying, setApplying]   = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading]     = useState(false);
  const [form, setForm] = useState({ fullName:'', email:'', phone:'', linkedin:'', coverLetter:'' });

  const co = job?.company || {};
  const saved = isJobSaved(job?._id);

  useEffect(() => {
    if (job) { document.body.style.overflow = 'hidden'; }
    return () => { document.body.style.overflow = ''; };
  }, [job]);

  if (!job) return null;

  const handleSave = async () => {
    if (!isAuth) { toast.info('Sign in to save jobs'); navigate('/login'); return; }
    const wasSaved = await toggleSave(job._id);
    toast.success(wasSaved ? 'Job saved!' : 'Removed from saved');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isAuth) { toast.info('Sign in to apply'); navigate('/login'); return; }
    if (!form.fullName || !form.email) { toast.error('Name and email are required'); return; }
    setLoading(true);
    try {
      await api.post(`/applications/job/${job._id}`, form);
      setSubmitted(true);
      toast.success(`Application sent to ${co.name}! 🎉`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Application failed');
    } finally { setLoading(false); }
  };

  return (
    <>
      <div className="drawer-overlay" onClick={onClose} />
      <div className="job-drawer" role="dialog" aria-label={job.title}>
        {/* Header */}
        <div className="drawer-header">
          <div>
            <div className="drawer-co-line">{co.name} · {job.location} · {job.type}</div>
            <div className="drawer-title">{job.title}</div>
          </div>
          <div style={{display:'flex',gap:8,alignItems:'center',flexShrink:0}}>
            <button className={`btn-save-drawer ${saved ? 'saved' : ''}`} onClick={handleSave}>
              <svg width="15" height="15" fill={saved?'currentColor':'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
              </svg>
            </button>
            <button className="drawer-close" onClick={onClose} aria-label="Close">
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M1 1l12 12M13 1 1 13" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
            </button>
          </div>
        </div>

        <div className="drawer-body">
          {/* Info Grid */}
          <div className="info-grid">
            <InfoBox label="Salary"     value={job.salaryDisplay || `${job.currency}${job.salaryMin}–${job.salaryMax}L`} />
            <InfoBox label="Work mode"  value={job.mode} />
            <InfoBox label="Experience" value={job.experience} />
            <InfoBox label="Domain"     value={job.domain} />
          </div>

          {/* Tags */}
          <div style={{display:'flex',flexWrap:'wrap',gap:6,marginTop:16}}>
            {(job.tags || []).map(t => <span key={t} className="dtag">{t}</span>)}
          </div>

          {/* Description */}
          <div className="drawer-section">
            <div className="dsec-title">About the role</div>
            <p className="drawer-text">{job.description}</p>
          </div>

          {/* Requirements */}
          {job.requirements?.length > 0 && (
            <div className="drawer-section">
              <div className="dsec-title">Requirements</div>
              <ul className="drawer-list">{job.requirements.map((r,i) => <li key={i}>{r}</li>)}</ul>
            </div>
          )}

          {/* Perks */}
          {job.perks?.length > 0 && (
            <div className="drawer-section">
              <div className="dsec-title">What we offer</div>
              <ul className="drawer-list">{job.perks.map((p,i) => <li key={i}>{p}</li>)}</ul>
            </div>
          )}

          {/* Apply Form */}
          <div className="apply-section">
            {submitted ? (
              <div className="apply-success">
                <div style={{fontSize:32}}>🎉</div>
                <h3>Application submitted!</h3>
                <p>We've sent your application to <strong>{co.name}</strong>. Good luck!</p>
              </div>
            ) : !applying ? (
              <button className="btn-apply-big" onClick={() => setApplying(true)}>
                Apply for this Role →
              </button>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="apply-form-title">Apply for this role</div>
                {[
                  { key:'fullName',    label:'Full name *',       type:'text',  placeholder:'Jane Smith' },
                  { key:'email',       label:'Email address *',   type:'email', placeholder:'jane@example.com' },
                  { key:'phone',       label:'Phone number',      type:'tel',   placeholder:'+91 98765 43210' },
                  { key:'linkedin',    label:'LinkedIn profile',  type:'url',   placeholder:'https://linkedin.com/in/…' },
                ].map(f => (
                  <div key={f.key} className="form-group">
                    <label className="form-label">{f.label}</label>
                    <input type={f.type} className="form-input" placeholder={f.placeholder}
                      value={form[f.key]} onChange={e => setForm(p => ({...p, [f.key]: e.target.value}))} />
                  </div>
                ))}
                <div className="form-group">
                  <label className="form-label">Cover note <span style={{color:'var(--ink-3)',fontWeight:400}}>(optional)</span></label>
                  <textarea className="form-input" rows={4} placeholder="What excites you about this role?"
                    value={form.coverLetter} onChange={e => setForm(p => ({...p, coverLetter: e.target.value}))} />
                </div>
                <div style={{display:'flex',gap:10,marginTop:4}}>
                  <button type="button" className="btn-ghost-sm" onClick={() => setApplying(false)}>Cancel</button>
                  <button type="submit" className="btn-submit" disabled={loading}>
                    {loading ? 'Sending…' : 'Submit Application'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default JobDrawer;
