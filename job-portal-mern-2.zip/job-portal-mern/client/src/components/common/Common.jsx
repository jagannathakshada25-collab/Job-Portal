// ── Footer.jsx ────────────────────────────────────────
import React from 'react';
import { Link } from 'react-router-dom';

export const Footer = () => (
  <footer style={{background:'var(--ink)',padding:'56px 32px 0'}}>
    <div style={{maxWidth:1200,margin:'0 auto',display:'grid',gridTemplateColumns:'1fr 2fr',gap:48,paddingBottom:48,borderBottom:'1px solid rgba(255,255,255,0.08)'}}>
      <div>
        <div style={{fontFamily:'var(--font-serif)',fontSize:20,color:'#fff',marginBottom:12}}>work<span style={{color:'var(--accent-3)',fontStyle:'italic'}}>flow</span></div>
        <p style={{fontSize:13.5,color:'rgba(255,255,255,0.4)',maxWidth:200,lineHeight:1.6}}>Connecting talent with opportunity since 2020.</p>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:32}}>
        {[
          { title:'For Job Seekers', links:[['Browse Jobs','/jobs'],['Saved Jobs','/saved-jobs'],['Applications','/applications'],['Salary Guide','/salaries']] },
          { title:'For Employers',   links:[['Post a Job','/post-job'],['Companies','/companies'],['Pricing','/pricing']] },
          { title:'Company',         links:[['About','/about'],['Blog','/blog'],['Contact','/contact']] },
        ].map(col => (
          <div key={col.title}>
            <div style={{fontSize:11,fontWeight:500,textTransform:'uppercase',letterSpacing:'1.2px',color:'rgba(255,255,255,0.35)',marginBottom:14}}>{col.title}</div>
            {col.links.map(([label, to]) => (
              <Link key={label} to={to} style={{display:'block',fontSize:13.5,color:'rgba(255,255,255,0.55)',marginBottom:10,transition:'color var(--t)'}}
                    onMouseOver={e=>e.target.style.color='#fff'} onMouseOut={e=>e.target.style.color='rgba(255,255,255,0.55)'}>{label}</Link>
            ))}
          </div>
        ))}
      </div>
    </div>
    <div style={{maxWidth:1200,margin:'0 auto',padding:'20px 0',display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:12}}>
      <span style={{fontSize:13,color:'rgba(255,255,255,0.3)'}}>© 2025 WorkFlow. All rights reserved.</span>
      <div style={{display:'flex',gap:20}}>
        {['Privacy Policy','Terms of Service','Cookie Policy'].map(t=>(
          <Link key={t} to="/" style={{fontSize:13,color:'rgba(255,255,255,0.3)'}}>{t}</Link>
        ))}
      </div>
    </div>
  </footer>
);

// ── Spinner.jsx ────────────────────────────────────────
export const Spinner = ({ size = 32, center = false }) => {
  const el = (
    <div style={{
      width:size, height:size, border:`3px solid var(--surface-3)`,
      borderTopColor:'var(--accent-2)', borderRadius:'50%',
      animation:'spin 0.7s linear infinite',
    }} />
  );
  if (!center) return el;
  return <div style={{display:'flex',justifyContent:'center',alignItems:'center',padding:48}}>{el}</div>;
};

// ── ProtectedRoute.jsx ────────────────────────────────
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export const ProtectedRoute = ({ children, employerOnly = false }) => {
  const { isAuth, loading, isEmployer } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner center />;
  if (!isAuth) return <Navigate to="/login" state={{ from: location }} replace />;
  if (employerOnly && !isEmployer) return <Navigate to="/" replace />;
  return children;
};

// ── EmptyState.jsx ─────────────────────────────────────
export const EmptyState = ({ icon, title, desc, action }) => (
  <div style={{display:'flex',flexDirection:'column',alignItems:'center',padding:'72px 24px',gap:12,textAlign:'center'}}>
    <div style={{fontSize:48,lineHeight:1}}>{icon || '🔍'}</div>
    <h3 style={{fontSize:18,fontWeight:500,color:'var(--ink)'}}>{title}</h3>
    {desc && <p style={{fontSize:14,color:'var(--ink-3)',maxWidth:320}}>{desc}</p>}
    {action}
  </div>
);
