import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
  const { user, logout, isAuth, isEmployer } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropOpen, setDropOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/'); setDropOpen(false); };

  return (
    <nav className="navbar">
      <Link to="/" className="nav-logo">work<span>flow</span></Link>

      <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
        <NavLink to="/jobs"      className={({isActive}) => isActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>Browse Jobs</NavLink>
        <NavLink to="/companies" className={({isActive}) => isActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>Companies</NavLink>
        <NavLink to="/salaries"  className={({isActive}) => isActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>Salaries</NavLink>
        <NavLink to="/blog"      className={({isActive}) => isActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>Blog</NavLink>
      </div>

      <div className="nav-actions">
        {isAuth ? (
          <div className="nav-user-wrap">
            <button className="nav-user-btn" onClick={() => setDropOpen(p => !p)}>
              <div className="nav-avatar">{user.name[0].toUpperCase()}</div>
              <span className="nav-user-name">{user.name.split(' ')[0]}</span>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            </button>
            {dropOpen && (
              <div className="nav-dropdown">
                <div className="nav-drop-header">
                  <div className="nav-drop-avatar">{user.name[0].toUpperCase()}</div>
                  <div>
                    <div className="nav-drop-name">{user.name}</div>
                    <div className="nav-drop-role">{user.role}</div>
                  </div>
                </div>
                <div className="nav-drop-divider" />
                <Link to="/profile"       className="nav-drop-item" onClick={() => setDropOpen(false)}>My Profile</Link>
                <Link to="/applications"  className="nav-drop-item" onClick={() => setDropOpen(false)}>My Applications</Link>
                <Link to="/saved-jobs"    className="nav-drop-item" onClick={() => setDropOpen(false)}>Saved Jobs</Link>
                {isEmployer && <Link to="/dashboard" className="nav-drop-item" onClick={() => setDropOpen(false)}>Employer Dashboard</Link>}
                {isEmployer && !user?.company && <Link to="/create-company" className="nav-drop-item" style={{color:'var(--accent)',fontWeight:500}} onClick={() => setDropOpen(false)}>⚡ Create Company Profile</Link>}
                <div className="nav-drop-divider" />
                <button className="nav-drop-logout" onClick={handleLogout}>Sign Out</button>
              </div>
            )}
          </div>
        ) : (
          <>
            <Link to="/login"    className="btn-outline-white">Sign In</Link>
            <Link to="/register" className="btn-red">Get Started</Link>
          </>
        )}
        {isEmployer && <Link to="/post-job" className="btn-red" style={{marginLeft: 8}}>Post a Job</Link>}
      </div>

      <button className="nav-hamburger" onClick={() => setMenuOpen(p => !p)} aria-label="Menu">
        <span className={menuOpen ? 'open' : ''} />
        <span className={menuOpen ? 'open' : ''} />
        <span className={menuOpen ? 'open' : ''} />
      </button>

      {menuOpen && <div className="nav-backdrop" onClick={() => setMenuOpen(false)} />}
    </nav>
  );
};

export default Navbar;
