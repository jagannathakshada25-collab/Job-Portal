import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/common/Common';
import Navbar from './components/common/Navbar';

import HomePage        from './pages/HomePage';
import JobsPage        from './pages/JobsPage';
import CompaniesPage   from './pages/CompaniesPage';
import PostJobPage        from './pages/PostJobPage';
import CreateCompanyPage  from './pages/CreateCompanyPage';
import { LoginPage, RegisterPage } from './pages/AuthPages';
import { ProfilePage, ApplicationsPage, SavedJobsPage, DashboardPage } from './pages/UserPages';
import { SalariesPage, BlogPage } from './pages/InfoPages';

import './styles/globals.css';

const NotFound = () => (
  <div style={{ textAlign:'center', padding:'120px 24px' }}>
    <div style={{ fontFamily:'var(--font-serif)', fontSize:80, color:'var(--surface-3)', lineHeight:1, marginBottom:16 }}>404</div>
    <h2 style={{ fontFamily:'var(--font-serif)', fontSize:28, marginBottom:12 }}>Page not found</h2>
    <p style={{ color:'var(--ink-3)', marginBottom:24 }}>The page you're looking for doesn't exist.</p>
    <a href="/" style={{ background:'var(--accent-2)', color:'#fff', padding:'10px 24px', borderRadius:'var(--radius-sm)', fontSize:14, fontWeight:500 }}>Go Home</a>
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Navbar />
        <Routes>
          {/* Public */}
          <Route path="/"          element={<HomePage />} />
          <Route path="/jobs"      element={<JobsPage />} />
          <Route path="/companies" element={<CompaniesPage />} />
          <Route path="/salaries"  element={<SalariesPage />} />
          <Route path="/blog"      element={<BlogPage />} />
          <Route path="/login"     element={<LoginPage />} />
          <Route path="/register"  element={<RegisterPage />} />

          {/* Protected – any auth */}
          <Route path="/profile"      element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="/applications" element={<ProtectedRoute><ApplicationsPage /></ProtectedRoute>} />
          <Route path="/saved-jobs"   element={<ProtectedRoute><SavedJobsPage /></ProtectedRoute>} />

          {/* Protected – employer only */}
          <Route path="/create-company" element={<ProtectedRoute employerOnly><CreateCompanyPage /></ProtectedRoute>} />
          <Route path="/post-job"       element={<ProtectedRoute employerOnly><PostJobPage /></ProtectedRoute>} />
          <Route path="/dashboard"      element={<ProtectedRoute employerOnly><DashboardPage /></ProtectedRoute>} />

          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>

        <ToastContainer
          position="bottom-center"
          autoClose={2800}
          hideProgressBar
          newestOnTop
          closeOnClick
          pauseOnHover
          theme="dark"
          style={{ fontSize: 13.5 }}
        />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
