import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(() => {
    try { return JSON.parse(localStorage.getItem('wf_user')) || null; } catch { return null; }
  });
  const [loading, setLoading] = useState(true);
  const [savedJobs, setSavedJobs] = useState([]);

  // Verify token on mount
  useEffect(() => {
    const token = localStorage.getItem('wf_token');
    if (!token) { setLoading(false); return; }
    api.get('/auth/me')
      .then(res => {
        setUser(res.data.user);
        setSavedJobs(res.data.user.savedJobs?.map(j => j._id || j) || []);
        localStorage.setItem('wf_user', JSON.stringify(res.data.user));
      })
      .catch(() => { localStorage.removeItem('wf_token'); localStorage.removeItem('wf_user'); setUser(null); })
      .finally(() => setLoading(false));
  }, []);

  const register = useCallback(async (data) => {
    const res = await api.post('/auth/register', data);
    localStorage.setItem('wf_token', res.data.token);
    localStorage.setItem('wf_user', JSON.stringify(res.data.user));
    setUser(res.data.user);
    return res.data;
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    localStorage.setItem('wf_token', res.data.token);
    localStorage.setItem('wf_user', JSON.stringify(res.data.user));
    setUser(res.data.user);
    setSavedJobs(res.data.user.savedJobs?.map(j => j._id || j) || []);
    return res.data;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('wf_token');
    localStorage.removeItem('wf_user');
    setUser(null);
    setSavedJobs([]);
  }, []);

  const updateProfile = useCallback(async (data) => {
    const res = await api.put('/auth/update-profile', data);
    setUser(res.data.user);
    localStorage.setItem('wf_user', JSON.stringify(res.data.user));
    return res.data;
  }, []);

  const toggleSave = useCallback(async (jobId) => {
    if (!user) return false;
    const res = await api.post(`/jobs/${jobId}/save`);
    setSavedJobs(res.data.savedJobs);
    return res.data.saved;
  }, [user]);

  const isJobSaved = useCallback((jobId) => {
    return savedJobs.some(id => id.toString() === jobId?.toString());
  }, [savedJobs]);

  return (
    <AuthContext.Provider value={{
      user, loading, savedJobs,
      register, login, logout, updateProfile, toggleSave, isJobSaved,
      isAuth: !!user,
      isEmployer: user?.role === 'employer' || user?.role === 'admin',
      isAdmin: user?.role === 'admin',
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
