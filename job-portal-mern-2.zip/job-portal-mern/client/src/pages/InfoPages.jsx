import React, { useState } from 'react';
import { Footer } from '../components/common/Common';

/* ─── SALARY DATA ────────────────────────────────────── */
const SALARY_DATA = [
  { role:'Staff Engineer',          median:155, low:120, high:200, growth:12, demand:90 },
  { role:'ML Engineer',             median:140, low:100, high:185, growth:22, demand:95 },
  { role:'Product Manager (Sr.)',   median:130, low:95,  high:170, growth:14, demand:85 },
  { role:'Data Scientist',          median:120, low:85,  high:165, growth:18, demand:88 },
  { role:'Senior Product Designer', median:110, low:75,  high:150, growth:10, demand:80 },
  { role:'Frontend Engineer',       median:105, low:70,  high:145, growth:8,  demand:92 },
  { role:'Backend Engineer',        median:108, low:72,  high:148, growth:9,  demand:91 },
  { role:'DevOps Engineer',         median:115, low:80,  high:155, growth:16, demand:87 },
  { role:'UX Researcher',           median:95,  low:65,  high:135, growth:8,  demand:72 },
  { role:'Growth Marketing Manager',median:85,  low:55,  high:125, growth:11, demand:75 },
  { role:'Android / iOS Engineer',  median:100, low:68,  high:140, growth:7,  demand:82 },
  { role:'Engineering Manager',     median:145, low:110, high:190, growth:10, demand:70 },
];

export const SalariesPage = () => {
  const [q, setQ]       = useState('');
  const [sort, setSort] = useState('median');

  let rows = SALARY_DATA.filter(d => !q || d.role.toLowerCase().includes(q.toLowerCase()));
  if (sort === 'median')  rows = [...rows].sort((a,b) => b.median - a.median);
  if (sort === 'growth')  rows = [...rows].sort((a,b) => b.growth - a.growth);
  if (sort === 'demand')  rows = [...rows].sort((a,b) => b.demand - a.demand);
  if (sort === 'alpha')   rows = [...rows].sort((a,b) => a.role.localeCompare(b.role));
  const max = Math.max(...SALARY_DATA.map(d => d.high));

  return (
    <div>
      <div style={{ background:'var(--accent-2)', padding:'48px 32px', textAlign:'center' }}>
        <h1 style={{ fontFamily:'var(--font-serif)', color:'#fff', fontSize:'clamp(26px,3.5vw,38px)', marginBottom:10 }}>2025 Tech Salary Guide</h1>
        <p style={{ color:'rgba(255,255,255,0.5)', fontSize:15 }}>Median compensation data across the most in-demand roles. Updated April 2025.</p>
      </div>

      <div style={{ maxWidth:1100, margin:'0 auto', padding:'40px 32px 80px' }}>
        <div style={{ display:'flex', gap:12, marginBottom:24, flexWrap:'wrap', alignItems:'center' }}>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search roles…"
            style={{ padding:'9px 13px', border:'1px solid var(--border-md)', borderRadius:'var(--radius-sm)', fontSize:14, outline:'none', fontFamily:'var(--font-sans)', minWidth:240 }} />
          <select value={sort} onChange={e => setSort(e.target.value)}
            style={{ padding:'9px 13px', border:'1px solid var(--border-md)', borderRadius:'var(--radius-sm)', fontSize:14, outline:'none', fontFamily:'var(--font-sans)', cursor:'pointer' }}>
            <option value="median">Sort by median salary</option>
            <option value="growth">Sort by growth rate</option>
            <option value="demand">Sort by demand</option>
            <option value="alpha">Alphabetical</option>
          </select>
        </div>

        <div style={{ background:'#fff', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr>
                {['Role','Median (LPA)','Range','YoY Growth','Demand'].map(h => (
                  <th key={h} style={{ textAlign:'left', fontSize:11.5, fontWeight:500, textTransform:'uppercase', letterSpacing:'0.8px', color:'var(--ink-3)', background:'var(--surface-2)', padding:'14px 20px', borderBottom:'1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(d => (
                <tr key={d.role} style={{ borderBottom:'1px solid var(--border)' }}>
                  <td style={{ padding:'14px 20px', fontWeight:500, color:'var(--ink)', fontSize:14 }}>{d.role}</td>
                  <td style={{ padding:'14px 20px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div style={{ width:120, height:6, background:'var(--surface-3)', borderRadius:99, overflow:'hidden', flexShrink:0 }}>
                        <div style={{ width:`${Math.round(d.median/max*100)}%`, height:'100%', background:'var(--accent-2)', borderRadius:99 }} />
                      </div>
                      <span style={{ fontSize:13, fontWeight:500, color:'var(--accent-2)' }}>₹{d.median}L</span>
                    </div>
                  </td>
                  <td style={{ padding:'14px 20px', fontSize:13, color:'var(--ink-3)' }}>₹{d.low}L – ₹{d.high}L</td>
                  <td style={{ padding:'14px 20px' }}>
                    <span style={{ fontSize:12.5, fontWeight:500, color:'var(--teal)' }}>↑ {d.growth}%</span>
                  </td>
                  <td style={{ padding:'14px 20px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <div style={{ width:80, height:6, background:'var(--surface-3)', borderRadius:99, overflow:'hidden' }}>
                        <div style={{ width:`${d.demand}%`, height:'100%', background:'var(--teal)', borderRadius:99 }} />
                      </div>
                      <span style={{ fontSize:12, color:'var(--ink-3)' }}>{d.demand}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p style={{ marginTop:16, fontSize:13, color:'var(--ink-3)' }}>Data aggregated from 14,000+ verified job listings. All figures in Indian Lakhs Per Annum (LPA). April 2025.</p>
      </div>
      <Footer />
    </div>
  );
};

/* ─── BLOG DATA ──────────────────────────────────────── */
const BLOG_POSTS = [
  { id:1, title:'How to negotiate your salary in a tough market',   category:'Career Advice', excerpt:'Proven strategies for getting the compensation you deserve, even when hiring budgets are tighter than usual.', date:'Apr 14, 2025', readTime:'6 min read', color:'#e8f0fb' },
  { id:2, title:'Remote work in 2025: what companies actually want', category:'Remote Work',   excerpt:'The landscape has shifted again. Here\'s what top employers expect from remote candidates this year.', date:'Apr 10, 2025', readTime:'5 min read', color:'#eaf3de' },
  { id:3, title:'The rise of the AI-augmented designer',             category:'Design Trends', excerpt:'How AI tools are changing the day-to-day of product designers — and which skills matter more than ever.', date:'Apr 6, 2025',  readTime:'8 min read', color:'#faeeda' },
  { id:4, title:'Staff vs Principal: what the title actually means', category:'Engineering',   excerpt:'Two senior-plus IC tracks that often confuse candidates. The real differences by company size.', date:'Apr 2, 2025',  readTime:'7 min read', color:'#fcebeb' },
  { id:5, title:'Building a standout portfolio with zero experience', category:'Career Advice', excerpt:'Entry-level doesn\'t mean no leverage. Here\'s how to craft a portfolio that opens senior doors.', date:'Mar 28, 2025', readTime:'5 min read', color:'#f0e8fb' },
  { id:6, title:'The PM hiring playbook has completely changed',      category:'Product',       excerpt:'Product roles are harder to land than ever — but the candidates getting offers all share a few key traits.', date:'Mar 24, 2025', readTime:'6 min read', color:'#e8f8fb' },
];

const BLOG_CATS = ['All','Career Advice','Remote Work','Engineering','Design Trends','Product'];

export const BlogPage = () => {
  const [cat, setCat] = useState('All');
  const posts = cat === 'All' ? BLOG_POSTS : BLOG_POSTS.filter(p => p.category === cat);

  return (
    <div>
      <div style={{ background:'var(--accent-2)', padding:'48px 32px', textAlign:'center' }}>
        <h1 style={{ fontFamily:'var(--font-serif)', color:'#fff', fontSize:'clamp(26px,3.5vw,38px)', marginBottom:10 }}>WorkFlow Career Blog</h1>
        <p style={{ color:'rgba(255,255,255,0.5)', fontSize:15 }}>Practical advice for job seekers, hiring managers, and career changers.</p>
      </div>

      <div style={{ maxWidth:1100, margin:'0 auto', padding:'36px 32px 80px' }}>
        <div style={{ display:'flex', gap:10, marginBottom:32, flexWrap:'wrap' }}>
          {BLOG_CATS.map(c => (
            <button key={c} onClick={() => setCat(c)}
              style={{ fontSize:12.5, padding:'5px 14px', borderRadius:99, border:'1px solid var(--border-md)', background: cat===c ? 'var(--accent-2)' : '#fff', color: cat===c ? '#fff' : 'var(--ink-2)', cursor:'pointer', transition:'all var(--t)', fontFamily:'var(--font-sans)' }}>
              {c}
            </button>
          ))}
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap:24 }}>
          {posts.map(p => (
            <div key={p.id} style={{ background:'#fff', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden', cursor:'pointer', transition:'all var(--t)' }}
              onMouseOver={e => e.currentTarget.style.boxShadow='var(--shadow-md)'}
              onMouseOut={e => e.currentTarget.style.boxShadow='none'}>
              <div style={{ height:160, background:p.color, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <span style={{ fontFamily:'var(--font-serif)', fontSize:22, color:'rgba(0,0,0,0.15)' }}>{p.category}</span>
              </div>
              <div style={{ padding:'18px 20px' }}>
                <div style={{ fontSize:11, fontWeight:500, textTransform:'uppercase', letterSpacing:1, color:'var(--accent)', marginBottom:8 }}>{p.category}</div>
                <div style={{ fontSize:16, fontWeight:500, color:'var(--ink)', lineHeight:1.4, marginBottom:8 }}>{p.title}</div>
                <div style={{ fontSize:13.5, color:'var(--ink-3)', lineHeight:1.6, marginBottom:14 }}>{p.excerpt}</div>
                <div style={{ display:'flex', justifyContent:'space-between', fontSize:12.5, color:'var(--ink-3)' }}>
                  <span>{p.date}</span><span>{p.readTime}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};
