import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import JobCard from '../components/jobs/JobCard';
import JobFilters from '../components/jobs/JobFilters';
import JobDrawer from '../components/jobs/JobDrawer';
import { Spinner, EmptyState } from '../components/common/Common';
import { Footer } from '../components/common/Common';
import './JobsPage.css';

const SORTS = [
  { value: 'relevant', label: 'Most relevant' },
  { value: 'newest',   label: 'Newest first' },
  { value: 'salary',   label: 'Salary: high to low' },
];

const useDebounce = (value, delay) => {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
};

const JobsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [jobs, setJobs]           = useState([]);
  const [total, setTotal]         = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading]     = useState(true);
  const [activeJob, setActiveJob] = useState(null);
  const [gridView, setGridView]   = useState(false);
  const [page, setPage]           = useState(1);
  const [sort, setSort]           = useState('relevant');

  const [searchQ, setSearchQ]     = useState(searchParams.get('q') || '');
  const [searchLoc, setSearchLoc] = useState(searchParams.get('location') || '');
  const [filters, setFilters]     = useState({
    type: searchParams.get('type') || '',
    mode: searchParams.get('mode') || '',
    experience: searchParams.get('experience') || '',
    domain: searchParams.get('domain') || '',
    minSalary: searchParams.get('minSalary') || 0,
  });

  const debouncedQ   = useDebounce(searchQ, 350);
  const debouncedLoc = useDebounce(searchLoc, 350);
  const panelRef = useRef(null);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (debouncedQ)           params.set('q', debouncedQ);
      if (debouncedLoc)         params.set('location', debouncedLoc);
      if (filters.type)         params.set('type', filters.type);
      if (filters.mode)         params.set('mode', filters.mode);
      if (filters.experience)   params.set('experience', filters.experience);
      if (filters.domain)       params.set('domain', filters.domain);
      if (filters.minSalary > 0) params.set('minSalary', filters.minSalary);
      params.set('sort', sort);
      params.set('page', page);
      params.set('limit', 8);

      const res = await api.get(`/jobs?${params}`);
      setJobs(res.data.jobs || []);
      setTotal(res.data.total || 0);
      setTotalPages(res.data.totalPages || 1);
    } catch {
      setJobs([]); setTotal(0);
    } finally { setLoading(false); }
  }, [debouncedQ, debouncedLoc, filters, sort, page]);

  useEffect(() => { fetchJobs(); }, [fetchJobs]);

  // Reset page when filters/search change
  useEffect(() => { setPage(1); }, [debouncedQ, debouncedLoc, filters, sort]);

  const handleFilterChange = (delta) => setFilters(p => ({ ...p, ...delta }));
  const clearFilters = () => {
    setFilters({ type:'', mode:'', experience:'', domain:'', minSalary: 0 });
    setSearchQ(''); setSearchLoc('');
    setPage(1);
  };

  const goPage = (n) => {
    setPage(n);
    panelRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="jobs-page">
      {/* Inline search bar */}
      <div className="jobs-search-bar">
        <div className="jsb-field">
          <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Job title, keyword…" />
        </div>
        <div className="jsb-field">
          <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          <input value={searchLoc} onChange={e => setSearchLoc(e.target.value)} placeholder="Location or Remote…" />
        </div>
      </div>

      <div className="jobs-layout">
        <JobFilters filters={filters} onChange={handleFilterChange} onClear={clearFilters} />

        <div className="jobs-main" ref={panelRef}>
          {/* Toolbar */}
          <div className="jobs-toolbar">
            <div className="jobs-count">
              <strong>{total.toLocaleString()} job{total !== 1 ? 's' : ''}</strong> found
            </div>
            <div className="toolbar-right">
              <select className="sort-select" value={sort} onChange={e => setSort(e.target.value)}>
                {SORTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
              <div className="view-toggle">
                <button className={`vtbtn ${!gridView ? 'active' : ''}`} onClick={() => setGridView(false)} title="List view">
                  <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><rect y="1" width="15" height="2" rx="1" fill="currentColor"/><rect y="6.5" width="15" height="2" rx="1" fill="currentColor"/><rect y="12" width="15" height="2" rx="1" fill="currentColor"/></svg>
                </button>
                <button className={`vtbtn ${gridView ? 'active' : ''}`} onClick={() => setGridView(true)} title="Grid view">
                  <svg width="15" height="15" viewBox="0 0 15 15" fill="none"><rect width="6" height="6" rx="1" fill="currentColor"/><rect x="9" width="6" height="6" rx="1" fill="currentColor"/><rect y="9" width="6" height="6" rx="1" fill="currentColor"/><rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor"/></svg>
                </button>
              </div>
            </div>
          </div>

          {/* Job list */}
          <div className={`job-list ${gridView ? 'grid' : ''}`}>
            {loading ? (
              <Spinner center />
            ) : jobs.length === 0 ? (
              <EmptyState icon="🔍" title="No jobs found" desc="Try adjusting your filters or broadening your search." />
            ) : (
              jobs.map((j, i) => <JobCard key={j._id} job={j} onOpen={setActiveJob} delay={i * 0.04} />)
            )}
          </div>

          {/* Pagination */}
          {totalPages > 1 && !loading && (
            <div className="pagination">
              <button className="page-btn" disabled={page === 1} onClick={() => goPage(page - 1)}>←</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).filter(p =>
                p === 1 || p === totalPages || Math.abs(p - page) <= 1
              ).reduce((acc, p, idx, arr) => {
                if (idx > 0 && p - arr[idx-1] > 1) acc.push('…');
                acc.push(p);
                return acc;
              }, []).map((p, i) =>
                p === '…'
                  ? <span key={`e${i}`} className="page-ellipsis">…</span>
                  : <button key={p} className={`page-btn ${p === page ? 'active' : ''}`} onClick={() => goPage(p)}>{p}</button>
              )}
              <button className="page-btn" disabled={page === totalPages} onClick={() => goPage(page + 1)}>→</button>
            </div>
          )}
        </div>
      </div>

      <Footer />
      {activeJob && <JobDrawer job={activeJob} onClose={() => setActiveJob(null)} />}
    </div>
  );
};

export default JobsPage;
