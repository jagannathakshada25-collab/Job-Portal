import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import './AuthPages.css';

// ── LOGIN ─────────────────────────────────────────────
export const LoginPage = () => {
  const { login } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const from = location.state?.from?.pathname || '/';
  const [form, setForm]     = useState({ email:'', password:'' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.error('Please fill in all fields'); return; }
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back! 👋');
      navigate(from, { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid credentials');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-visual">
        <h2>Your next career <em>chapter</em> starts here.</h2>
        <p>Access thousands of curated roles from companies that are serious about great talent.</p>
        <div className="auth-testimonial">
          <p>"I went from struggling to get callbacks to having three offers in six weeks. WorkFlow completely changed my job search."</p>
          <div className="auth-testimonial-author">— Priya Mehta, Senior PM at Notion</div>
        </div>
      </div>

      <div className="auth-form-wrap">
        <div className="auth-form-inner">
          <div className="auth-form-title">Welcome back</div>
          <div className="auth-form-sub">Sign in to your WorkFlow account</div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" className="form-input" placeholder="jane@example.com"
                value={form.email} onChange={e => setForm(p => ({...p, email: e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-input" placeholder="••••••••"
                value={form.password} onChange={e => setForm(p => ({...p, password: e.target.value}))} />
              <div className="form-hint"><a href="#" style={{color:'var(--accent-2)'}}>Forgot password?</a></div>
            </div>
            <button type="submit" className="btn-auth" disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
          <div className="auth-switch">
            Don't have an account? <Link to="/register">Create one free →</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

// ── REGISTER ──────────────────────────────────────────
export const RegisterPage = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm]     = useState({ name:'', email:'', password:'', role:'jobseeker' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) { toast.error('Please fill all fields'); return; }
    if (form.password.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    setLoading(true);
    try {
      await register(form);
      toast.success('Account created! Welcome to WorkFlow 🎉');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-visual">
        <h2>Join <em>98,000+</em> professionals finding work they love.</h2>
        <p>Whether you're job seeking or hiring, WorkFlow gives you the tools to move faster.</p>
        <div className="auth-testimonial">
          <p>"The salary guide alone saved me ₹20L in my negotiation. The job listings are actually curated — not just scraped noise."</p>
          <div className="auth-testimonial-author">— Arjun Reddy, Staff Engineer at Vercel</div>
        </div>
      </div>

      <div className="auth-form-wrap">
        <div className="auth-form-inner">
          <div className="auth-form-title">Create your account</div>
          <div className="auth-form-sub">It's free — always.</div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full name</label>
              <input type="text" className="form-input" placeholder="Jane Smith"
                value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" className="form-input" placeholder="jane@example.com"
                value={form.email} onChange={e => setForm(p => ({...p, email: e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-input" placeholder="Min 6 characters"
                value={form.password} onChange={e => setForm(p => ({...p, password: e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label">I am a…</label>
              <div className="role-toggle">
                {[['jobseeker','Job Seeker'],['employer','Employer']].map(([val, label]) => (
                  <button key={val} type="button"
                    className={`role-btn ${form.role === val ? 'active' : ''}`}
                    onClick={() => setForm(p => ({...p, role: val}))}>
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <button type="submit" className="btn-auth" disabled={loading}>
              {loading ? 'Creating account…' : 'Create Account'}
            </button>
          </form>
          <div className="auth-switch">
            Already have an account? <Link to="/login">Sign in →</Link>
          </div>
        </div>
      </div>
    </div>
  );
};
