import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../utils/api';
import { Spinner, EmptyState, Footer } from '../components/common/Common';
import JobCard from '../components/jobs/JobCard';
import JobDrawer from '../components/jobs/JobDrawer';

/* ═══════════════════════════════════════════════════
   PROFILE PAGE
═══════════════════════════════════════════════════ */
export const ProfilePage = () => {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || '', headline: user?.headline || '',
    location: user?.location || '', linkedin: user?.linkedin || '',
    github: user?.github || '', portfolio: user?.portfolio || '',
    skills: (user?.skills || []).join(', '),
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProfile({ ...form, skills: form.skills.split(',').map(s => s.trim()).filter(Boolean) });
      toast.success('Profile updated!');
    } catch { toast.error('Update failed'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: '48px 24px 80px' }}>
      <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, marginBottom: 8 }}>My Profile</h1>
      <p style={{ color: 'var(--ink-3)', marginBottom: 32 }}>Keep your profile up-to-date to attract better opportunities.</p>

      <div style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 28 }}>
        <form onSubmit={handleSubmit}>
          {[
            { key: 'name',      label: 'Full name',      type: 'text',  placeholder: 'Jane Smith' },
            { key: 'headline',  label: 'Headline',        type: 'text',  placeholder: 'Senior Product Designer at ...' },
            { key: 'location',  label: 'Location',        type: 'text',  placeholder: 'Mumbai, India' },
            { key: 'linkedin',  label: 'LinkedIn URL',    type: 'url',   placeholder: 'https://linkedin.com/in/...' },
            { key: 'github',    label: 'GitHub URL',      type: 'url',   placeholder: 'https://github.com/...' },
            { key: 'portfolio', label: 'Portfolio URL',   type: 'url',   placeholder: 'https://yoursite.com' },
            { key: 'skills',    label: 'Skills (comma separated)', type: 'text', placeholder: 'React, Figma, Python' },
          ].map(f => (
            <div key={f.key} className="form-group" style={{ marginBottom: 16 }}>
              <label className="form-label" style={{ display: 'block', fontSize: 13, fontWeight: 500, color: 'var(--ink-2)', marginBottom: 5 }}>{f.label}</label>
              <input type={f.type} className="form-input"
                style={{ width: '100%', padding: '9px 13px', border: '1px solid var(--border-md)', borderRadius: 'var(--radius-sm)', fontSize: 14, color: 'var(--ink)', outline: 'none', fontFamily: 'var(--font-sans)' }}
                placeholder={f.placeholder} value={form[f.key]}
                onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
            </div>
          ))}
          <button type="submit" disabled={loading}
            style={{ background: 'var(--accent-2)', color: '#fff', border: 'none', borderRadius: 'var(--radius-sm)', padding: '10px 28px', fontSize: 14, fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--font-sans)', opacity: loading ? 0.6 : 1 }}>
            {loading ? 'Saving…' : 'Save Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

/* ═══════════════════════════════════════════════════
   MY APPLICATIONS
═══════════════════════════════════════════════════ */
const STATUS_COLORS = {
  pending:     { bg: '#faeeda', color: '#7a4208' },
  reviewing:   { bg: '#e8f0fb', color: '#18469a' },
  shortlisted: { bg: '#eaf3de', color: '#2a5c12' },
  interviewed: { bg: '#f0e8fb', color: '#6b21a8' },
  offered:     { bg: '#eaf6f4', color: '#0a5e53' },
  rejected:    { bg: '#fcebeb', color: '#8f2020' },
  withdrawn:   { bg: 'var(--surface-2)', color: 'var(--ink-3)' },
};

export const ApplicationsPage = () => {
  const [apps, setApps]       = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/applications/my')
      .then(r => setApps(r.data.applications || []))
      .catch(() => setApps([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner center />;

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '48px 24px 80px' }}>
      <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, marginBottom: 8 }}>My Applications</h1>
      <p style={{ color: 'var(--ink-3)', marginBottom: 32 }}>{apps.length} application{apps.length !== 1 ? 's' : ''} submitted</p>

      {apps.length === 0 ? (
        <EmptyState icon="📋" title="No applications yet" desc="Browse jobs and start applying." action={<Link to="/jobs" style={{ background: 'var(--accent-2)', color: '#fff', padding: '9px 22px', borderRadius: 'var(--radius-sm)', fontSize: 14, fontWeight: 500 }}>Browse Jobs</Link>} />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {apps.map(a => {
            const sc = STATUS_COLORS[a.status] || STATUS_COLORS.pending;
            const co = a.company || {};
            const job = a.job || {};
            return (
              <div key={a._id} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                <div style={{ width: 42, height: 42, borderRadius: 10, background: co.logoColor || '#e8f0fb', color: co.logoText || '#185fa5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 600, flexShrink: 0, border: '1px solid var(--border)' }}>
                  {(co.name || '?')[0]}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--ink)', marginBottom: 2 }}>{job.title || 'Unknown role'}</div>
                  <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>{co.name} · {job.mode} · {job.salaryDisplay}</div>
                </div>
                <span style={{ fontSize: 12, fontWeight: 500, padding: '4px 12px', borderRadius: 99, background: sc.bg, color: sc.color, textTransform: 'capitalize', flexShrink: 0 }}>
                  {a.status}
                </span>
                <div style={{ fontSize: 12, color: 'var(--ink-3)', flexShrink: 0 }}>
                  {new Date(a.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};/* ═══════════════════════════════════════════════════
   SAVED JOBS
═══════════════════════════════════════════════════ */
export const SavedJobsPage = () => {
  const [savedJobs, setSavedJobs] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [activeJob, setActiveJob] = useState(null);

  useEffect(() => {
    api.get('/users/saved-jobs')
      .then(r => setSavedJobs(r.data.savedJobs || []))
      .catch(() => setSavedJobs([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner center />;

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '48px 24px 80px' }}>
      <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, marginBottom: 8 }}>Saved Jobs</h1>
      <p style={{ color: 'var(--ink-3)', marginBottom: 32 }}>{savedJobs.length} saved job{savedJobs.length !== 1 ? 's' : ''}</p>

      {savedJobs.length === 0 ? (
        <EmptyState icon="🔖" title="No saved jobs yet" desc="Save jobs while browsing to find them here." action={<Link to="/jobs" style={{ background: 'var(--accent-2)', color: '#fff', padding: '9px 22px', borderRadius: 'var(--radius-sm)', fontSize: 14, fontWeight: 500 }}>Browse Jobs</Link>} />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {savedJobs.map((j, i) => <JobCard key={j._id} job={j} onOpen={setActiveJob} delay={i * 0.04} />)}
        </div>
      )}
      {activeJob && <JobDrawer job={activeJob} onClose={() => setActiveJob(null)} />}
    </div>
  );
};

/* ═══════════════════════════════════════════════════
   EMPLOYER DASHBOARD
═══════════════════════════════════════════════════ */
export const DashboardPage = () => {
  const { user } = useAuth();
  const [jobs, setJobs]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.company) { setLoading(false); return; }
    api.get('/jobs?limit=20')
      .then(r => setJobs((r.data.jobs || [])))
      .catch(() => setJobs([]))
      .finally(() => setLoading(false));
  }, [user]);

  const deleteJob = async (id) => {
    if (!window.confirm('Delete this job listing?')) return;
    try {
      await api.delete(`/jobs/${id}`);
      setJobs(p => p.filter(j => j._id !== id));
      toast.success('Job deleted');
    } catch { toast.error('Could not delete job'); }
  };

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '48px 24px 80px' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 32 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, marginBottom: 4 }}>Employer Dashboard</h1>
          <p style={{ color: 'var(--ink-3)' }}>Manage your job listings and applications</p>
        </div>
        <Link to="/post-job" style={{ background: 'var(--accent)', color: '#fff', padding: '10px 22px', borderRadius: 'var(--radius-sm)', fontSize: 14, fontWeight: 500 }}>+ Post a Job</Link>
      </div>

      {/* No company guard */}
      {!user?.company ? (
        <div style={{ textAlign:'center', padding:'60px 24px', background:'#fff', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)' }}>
          <div style={{ fontSize:48, marginBottom:12 }}>🏢</div>
          <h3 style={{ fontFamily:'var(--font-serif)', fontSize:22, color:'var(--ink)', marginBottom:8 }}>Set up your company profile</h3>
          <p style={{ fontSize:14, color:'var(--ink-3)', maxWidth:380, margin:'0 auto 24px', lineHeight:1.7 }}>
            Create your company profile to start posting jobs and receiving applications from top candidates.
          </p>
          <Link to="/create-company" style={{ background:'var(--accent-2)', color:'#fff', padding:'10px 28px', borderRadius:'var(--radius-sm)', fontSize:14, fontWeight:500, display:'inline-block' }}>
            Create Company Profile →
          </Link>
        </div>
      ) : loading ? <Spinner center /> : jobs.length === 0 ? (
        <EmptyState icon="📋" title="No job listings yet" desc="Post your first job to start receiving applications." action={<Link to="/post-job" style={{ background: 'var(--accent)', color: '#fff', padding: '9px 22px', borderRadius: 'var(--radius-sm)', fontSize: 14, fontWeight: 500 }}>Post a Job</Link>} />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {jobs.map(j => {
            const co = j.company || {};
            return (
              <div key={j._id} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 500, fontSize: 15, color: 'var(--ink)', marginBottom: 3 }}>{j.title}</div>
                  <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>{co.name} · {j.location} · {j.type} · {j.mode}</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 4 }}>{j.applicationsCount || 0} applicants · {j.views || 0} views</div>
                </div>
                <span style={{ fontSize: 12, fontWeight: 500, padding: '4px 12px', borderRadius: 99, background: j.isActive ? '#eaf3de' : '#fcebeb', color: j.isActive ? '#2a5c12' : '#8f2020', flexShrink: 0 }}>
                  {j.isActive ? 'Active' : 'Expired'}
                </span>
                <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                  <Link to={`/post-job/edit/${j._id}`} style={{ fontSize: 13, color: 'var(--accent-2)', border: '1px solid var(--border-md)', borderRadius: 'var(--radius-sm)', padding: '6px 14px' }}>Edit</Link>
                  <button onClick={() => deleteJob(j._id)} style={{ fontSize: 13, color: 'var(--accent)', border: '1px solid rgba(214,63,46,0.25)', borderRadius: 'var(--radius-sm)', padding: '6px 14px', cursor: 'pointer', background: 'none', fontFamily: 'var(--font-sans)' }}>Delete</button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
