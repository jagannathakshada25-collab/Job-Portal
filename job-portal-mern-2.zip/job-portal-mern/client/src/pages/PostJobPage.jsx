import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../utils/api';
import './PostJobPage.css';

const FIELD = ({ label, required, children, hint }) => (
  <div className="form-group">
    <label className="form-label">{label}{required && ' *'}</label>
    {children}
    {hint && <div className="form-hint">{hint}</div>}
  </div>
);

const SELECT = ({ value, onChange, options, placeholder }) => (
  <select className="form-input" value={value} onChange={e => onChange(e.target.value)}>
    <option value="">{placeholder}</option>
    {options.map(o => <option key={o} value={o}>{o}</option>)}
  </select>
);

const PostJobPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title:'', location:'', mode:'Remote', type:'Full-time', experience:'Senior',
    domain:'Engineering', salaryMin:'', salaryMax:'', salaryDisplay:'', currency:'₹',
    description:'', requirements:'', perks:'', tags:'', featured: false,
    company: user?.company || '',
  });

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.location || !form.description) {
      toast.error('Please fill in all required fields'); return;
    }
    if (!form.company) {
      // Show friendly UI block — handled below via early return
      return;
    }
    setLoading(true);
    try {
      const payload = {
        ...form,
        salaryMin: Number(form.salaryMin) || 0,
        salaryMax: Number(form.salaryMax) || 0,
        salaryDisplay: form.salaryDisplay || `${form.currency}${form.salaryMin}–${form.salaryMax}L`,
        requirements: form.requirements.split('\n').filter(Boolean),
        perks:        form.perks.split('\n').filter(Boolean),
        tags:         form.tags.split(',').map(t => t.trim()).filter(Boolean),
      };
      await api.post('/jobs', payload);
      toast.success('Job posted successfully! 🎉');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to post job');
    } finally { setLoading(false); }
  };

  // ── No company profile guard ──────────────────────────
  if (!user?.company) {
    return (
      <div style={{ maxWidth: 560, margin: '80px auto', padding: '0 24px', textAlign: 'center' }}>
        <div style={{ fontSize: 52, marginBottom: 16 }}>🏢</div>
        <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 26, color: 'var(--ink)', marginBottom: 10 }}>
          First, create your company profile
        </h2>
        <p style={{ fontSize: 15, color: 'var(--ink-3)', lineHeight: 1.7, marginBottom: 28, maxWidth: 420, margin: '0 auto 28px' }}>
          You need a company profile before you can post jobs. It only takes 2 minutes and lets candidates
          learn more about your team and culture.
        </p>
        <Link
          to="/create-company"
          style={{
            display: 'inline-block',
            background: 'var(--accent-2)', color: '#fff',
            padding: '12px 32px', borderRadius: 'var(--radius-sm)',
            fontSize: 15, fontWeight: 500,
            transition: 'all var(--t)',
          }}
        >
          Create Company Profile →
        </Link>
        <div style={{ marginTop: 16 }}>
          <Link to="/dashboard" style={{ fontSize: 13.5, color: 'var(--ink-3)' }}>← Back to Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="post-job-page">
      <div className="pj-header">
        <h1>Post a job listing</h1>
        <p>Reach thousands of qualified candidates actively looking for their next role.</p>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Job Details */}
        <div className="pj-card">
          <div className="pj-section-title">Job details</div>
          <FIELD label="Job title" required>
            <input className="form-input" placeholder="e.g. Senior Product Designer" value={form.title} onChange={e => set('title', e.target.value)} />
          </FIELD>
          <div className="form-row">
            <FIELD label="Location" required>
              <input className="form-input" placeholder="City, Country or Remote" value={form.location} onChange={e => set('location', e.target.value)} />
            </FIELD>
            <FIELD label="Work mode">
              <SELECT value={form.mode} onChange={v => set('mode', v)} options={['Remote','Hybrid','On-site']} placeholder="Select mode" />
            </FIELD>
          </div>
          <div className="form-row">
            <FIELD label="Job type">
              <SELECT value={form.type} onChange={v => set('type', v)} options={['Full-time','Part-time','Contract','Freelance','Internship']} placeholder="Select type" />
            </FIELD>
            <FIELD label="Experience level">
              <SELECT value={form.experience} onChange={v => set('experience', v)} options={['Entry level','Mid-senior','Senior','Lead / Principal','Director+']} placeholder="Select level" />
            </FIELD>
          </div>
          <div className="form-row">
            <FIELD label="Domain">
              <SELECT value={form.domain} onChange={v => set('domain', v)} options={['Design','Engineering','Product','Data','Marketing','Finance','Operations','Sales','HR']} placeholder="Select domain" />
            </FIELD>
            <FIELD label="Currency">
              <SELECT value={form.currency} onChange={v => set('currency', v)} options={['₹','$','€','£']} placeholder="Currency" />
            </FIELD>
          </div>
          <div className="form-row">
            <FIELD label="Salary min (LPA/k)">
              <input type="number" className="form-input" placeholder="e.g. 60" value={form.salaryMin} onChange={e => set('salaryMin', e.target.value)} />
            </FIELD>
            <FIELD label="Salary max (LPA/k)">
              <input type="number" className="form-input" placeholder="e.g. 90" value={form.salaryMax} onChange={e => set('salaryMax', e.target.value)} />
            </FIELD>
          </div>
          <FIELD label="Salary display text" hint="How it shows on the listing, e.g. ₹60–90L or $120k–$160k">
            <input className="form-input" placeholder="₹60–90L" value={form.salaryDisplay} onChange={e => set('salaryDisplay', e.target.value)} />
          </FIELD>
          <div className="pj-featured-toggle">
            <label className="toggle-label">
              <input type="checkbox" checked={form.featured} onChange={e => set('featured', e.target.checked)} />
              <span>Mark as featured listing</span>
              <span className="toggle-sub">(Featured jobs appear at the top of search results)</span>
            </label>
          </div>
        </div>

        {/* Description */}
        <div className="pj-card">
          <div className="pj-section-title">Job description</div>
          <FIELD label="About the role" required>
            <textarea className="form-input" rows={6} placeholder="Describe the role, team, and what success looks like in the first 90 days…" value={form.description} onChange={e => set('description', e.target.value)} />
          </FIELD>
          <FIELD label="Requirements" hint="One requirement per line">
            <textarea className="form-input" rows={5} placeholder={"5+ years of product design experience\nExpert proficiency in Figma\nStrong portfolio"} value={form.requirements} onChange={e => set('requirements', e.target.value)} />
          </FIELD>
          <FIELD label="Benefits & perks" hint="One perk per line">
            <textarea className="form-input" rows={4} placeholder={"Competitive equity\nComprehensive health coverage\nRemote-first culture"} value={form.perks} onChange={e => set('perks', e.target.value)} />
          </FIELD>
          <FIELD label="Skills / tags" hint="Comma separated, e.g. Figma, React, Python">
            <input className="form-input" placeholder="Figma, Design Systems, User Research" value={form.tags} onChange={e => set('tags', e.target.value)} />
          </FIELD>
        </div>

        <div className="pj-actions">
          <button type="button" className="btn-ghost-pj" onClick={() => navigate(-1)}>Cancel</button>
          <button type="submit" className="btn-post" disabled={loading}>
            {loading ? 'Posting…' : 'Publish Job →'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PostJobPage;
