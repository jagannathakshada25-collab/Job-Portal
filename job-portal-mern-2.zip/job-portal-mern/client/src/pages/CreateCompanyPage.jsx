import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import api from '../utils/api';
import './CreateCompanyPage.css';

const INDUSTRIES = [
  'Technology', 'Fintech', 'Design Tools', 'E-commerce', 'Productivity',
  'Cloud / DevTools', 'Infrastructure', 'Travel', 'Healthcare', 'Education',
  'Media & Entertainment', 'Retail', 'Logistics', 'Real Estate', 'Other',
];

const SIZES = ['1-10', '11-50', '51-200', '201-1000', '1001-5000', '5000+'];

const LOGO_PRESETS = [
  { logoColor: '#e8f0fb', logoText: '#185fa5', coverColor: '#1a73e8' },
  { logoColor: '#faeeda', logoText: '#854f0b', coverColor: '#635BFF' },
  { logoColor: '#eaf3de', logoText: '#2a5c12', coverColor: '#0e7c6e' },
  { logoColor: '#fcebeb', logoText: '#a32d2d', coverColor: '#d63f2e' },
  { logoColor: '#f0e8fb', logoText: '#6b21a8', coverColor: '#7c3aed' },
  { logoColor: '#e8f8fb', logoText: '#0e6e7c', coverColor: '#0891b2' },
  { logoColor: '#fef3c7', logoText: '#92400e', coverColor: '#d97706' },
  { logoColor: '#e8e4dc', logoText: '#0f0e0c', coverColor: '#1a1a2e' },
];

const Field = ({ label, required, hint, children }) => (
  <div className="cc-field">
    <label className="cc-label">{label}{required && <span className="cc-req"> *</span>}</label>
    {children}
    {hint && <p className="cc-hint">{hint}</p>}
  </div>
);

const CreateCompanyPage = () => {
  const { user, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading]     = useState(false);
  const [checkLoading, setCheckLoading] = useState(true);
  const [preset, setPreset]       = useState(0);
  const [form, setForm] = useState({
    name: '',
    description: '',
    industry: '',
    size: '51-200',
    founded: '',
    website: '',
    location: '',
    linkedin: '',
    twitter: '',
    logoColor: LOGO_PRESETS[0].logoColor,
    logoText:  LOGO_PRESETS[0].logoText,
    coverColor: LOGO_PRESETS[0].coverColor,
  });

  // If user already has a company, redirect to dashboard
  useEffect(() => {
    if (user?.company) {
      toast.info('You already have a company profile.');
      navigate('/dashboard');
    } else {
      setCheckLoading(false);
    }
  }, [user, navigate]);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const pickPreset = (i) => {
    setPreset(i);
    const p = LOGO_PRESETS[i];
    setForm(prev => ({ ...prev, ...p }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim())     { toast.error('Company name is required'); return; }
    if (!form.industry)        { toast.error('Please select an industry'); return; }
    if (!form.description.trim()) { toast.error('Description is required'); return; }

    setLoading(true);
    try {
      const payload = {
        ...form,
        founded: form.founded ? Number(form.founded) : undefined,
      };
      const res = await api.post('/companies', payload);

      // Update local user context so company ID is set
      await updateProfile({ company: res.data.company._id });

      toast.success(`"${res.data.company.name}" created successfully! 🎉`);
      navigate('/post-job');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create company');
    } finally {
      setLoading(false);
    }
  };

  if (checkLoading) return null;

  const initials = form.name ? form.name[0].toUpperCase() : '?';

  return (
    <div className="cc-page">
      {/* Header */}
      <div className="cc-header">
        <h1>Create your company profile</h1>
        <p>Set up your company page before posting jobs. This takes less than 2 minutes.</p>
      </div>

      <div className="cc-layout">
        {/* Preview card */}
        <aside className="cc-preview">
          <div className="cc-preview-label">Live preview</div>
          <div className="cc-preview-card">
            <div className="cc-preview-cover" style={{ background: form.coverColor }}>
              <span className="cc-preview-cover-name">{form.name || 'Your Company'}</span>
            </div>
            <div className="cc-preview-body">
              <div className="cc-preview-logo" style={{ background: form.logoColor, color: form.logoText }}>
                {initials}
              </div>
              <div className="cc-preview-name">{form.name || 'Company Name'}</div>
              <div className="cc-preview-industry">{form.industry || 'Industry'}</div>
              <div className="cc-preview-meta">
                {form.size && <span>{form.size} employees</span>}
                {form.founded && <span>Est. {form.founded}</span>}
                {form.location && <span>📍 {form.location}</span>}
              </div>
              <div className="cc-preview-desc">
                {form.description ? form.description.slice(0, 100) + (form.description.length > 100 ? '…' : '') : 'Your company description will appear here.'}
              </div>
            </div>
          </div>

          {/* Colour presets */}
          <div className="cc-presets">
            <div className="cc-presets-label">Colour theme</div>
            <div className="cc-presets-grid">
              {LOGO_PRESETS.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  className={`cc-preset-dot ${preset === i ? 'active' : ''}`}
                  style={{ background: p.coverColor }}
                  onClick={() => pickPreset(i)}
                  aria-label={`Theme ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </aside>

        {/* Form */}
        <form className="cc-form" onSubmit={handleSubmit}>
          {/* Basic info */}
          <div className="cc-card">
            <div className="cc-card-title">Company information</div>

            <Field label="Company name" required>
              <input
                className="cc-input"
                placeholder="e.g. Acme Corp"
                value={form.name}
                onChange={e => set('name', e.target.value)}
              />
            </Field>

            <div className="cc-row">
              <Field label="Industry" required>
                <select className="cc-input" value={form.industry} onChange={e => set('industry', e.target.value)}>
                  <option value="">Select industry…</option>
                  {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
                </select>
              </Field>
              <Field label="Company size">
                <select className="cc-input" value={form.size} onChange={e => set('size', e.target.value)}>
                  {SIZES.map(s => <option key={s} value={s}>{s} employees</option>)}
                </select>
              </Field>
            </div>

            <div className="cc-row">
              <Field label="Founded year" hint="e.g. 2015">
                <input
                  className="cc-input"
                  type="number"
                  placeholder="2015"
                  min="1800" max={new Date().getFullYear()}
                  value={form.founded}
                  onChange={e => set('founded', e.target.value)}
                />
              </Field>
              <Field label="Headquarters location">
                <input
                  className="cc-input"
                  placeholder="Mumbai, India or Remote"
                  value={form.location}
                  onChange={e => set('location', e.target.value)}
                />
              </Field>
            </div>

            <Field label="About the company" required hint="Tell candidates what makes your company a great place to work.">
              <textarea
                className="cc-input cc-textarea"
                rows={5}
                placeholder="We're building the future of… Our team of 50+ people works on… We value autonomy, learning, and shipping great products."
                value={form.description}
                onChange={e => set('description', e.target.value)}
              />
            </Field>
          </div>

          {/* Links */}
          <div className="cc-card">
            <div className="cc-card-title">Links & social</div>
            <Field label="Company website">
              <input
                className="cc-input"
                type="url"
                placeholder="https://yourcompany.com"
                value={form.website}
                onChange={e => set('website', e.target.value)}
              />
            </Field>
            <div className="cc-row">
              <Field label="LinkedIn">
                <input
                  className="cc-input"
                  type="url"
                  placeholder="https://linkedin.com/company/…"
                  value={form.linkedin}
                  onChange={e => set('linkedin', e.target.value)}
                />
              </Field>
              <Field label="Twitter / X">
                <input
                  className="cc-input"
                  type="url"
                  placeholder="https://twitter.com/…"
                  value={form.twitter}
                  onChange={e => set('twitter', e.target.value)}
                />
              </Field>
            </div>
          </div>

          {/* Actions */}
          <div className="cc-actions">
            <button type="button" className="cc-btn-ghost" onClick={() => navigate(-1)}>
              Cancel
            </button>
            <button type="submit" className="cc-btn-submit" disabled={loading}>
              {loading ? 'Creating…' : 'Create Company & Continue →'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateCompanyPage;
