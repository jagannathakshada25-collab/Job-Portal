import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { Spinner, EmptyState, Footer } from '../components/common/Common';
import './CompaniesPage.css';

const INDUSTRIES = ['All','Technology','Fintech','Design Tools','E-commerce','Productivity','Cloud / DevTools','Infrastructure','Travel'];

const CompaniesPage = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState('');
  const [industry, setIndustry]   = useState('All');

  useEffect(() => {
    const params = new URLSearchParams();
    if (search && search.length > 1) params.set('q', search);
    if (industry !== 'All') params.set('industry', industry);
    setLoading(true);
    api.get(`/companies?${params}&limit=24`)
      .then(r => setCompanies(r.data.companies || []))
      .catch(() => setCompanies([]))
      .finally(() => setLoading(false));
  }, [search, industry]);

  return (
    <div>
      {/* Hero */}
      <div className="co-hero">
        <h1>Discover great companies</h1>
        <p>Find employers that match your values, culture, and career aspirations.</p>
        <div className="co-search-wrap">
          <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" style={{color:'var(--ink-3)',flexShrink:0}}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search companies…" className="co-search-input" />
        </div>
      </div>

      {/* Industry filter */}
      <div className="co-filter-bar">
        {INDUSTRIES.map(i => (
          <button key={i} className={`ind-chip ${industry === i ? 'active' : ''}`} onClick={() => setIndustry(i)}>{i}</button>
        ))}
      </div>

      <div className="co-grid-wrap">
        {loading ? <Spinner center /> : companies.length === 0 ? (
          <EmptyState icon="🏢" title="No companies found" desc="Try a different search or industry." />
        ) : (
          <div className="co-grid">
            {companies.map(c => (
              <Link key={c._id} to={`/jobs?q=${encodeURIComponent(c.name)}`} className="co-card-full">
                <div className="co-cover" style={{ background: c.coverColor || '#1a73e8' }}>
                  <span className="co-cover-name">{c.name}</span>
                </div>
                <div className="co-card-body">
                  <div className="co-logo-big" style={{ background: c.logoColor, color: c.logoText }}>{(c.name||'?')[0]}</div>
                  <div className="co-name">{c.name}</div>
                  <div className="co-industry">{c.industry}</div>
                  <div className="co-stats">
                    <span><strong>{c.size}</strong> employees</span>
                    {c.founded && <span>Est. <strong>{c.founded}</strong></span>}
                    {c.rating > 0 && <span>★ <strong>{c.rating}</strong></span>}
                  </div>
                  {c.openJobs > 0 && <span className="co-open-jobs">{c.openJobs} open roles</span>}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default CompaniesPage;
