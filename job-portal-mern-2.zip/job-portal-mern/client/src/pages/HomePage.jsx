import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import JobCard from '../components/jobs/JobCard';
import JobDrawer from '../components/jobs/JobDrawer';
import { Spinner } from '../components/common/Common';
import { Footer } from '../components/common/Common';
import './HomePage.css';

const CATEGORIES = [
  { name:'Design',      count:'1,240', icon:'🎨', color:'#e8f0fb', text:'#185fa5', link:'/jobs?domain=Design' },
  { name:'Engineering', count:'4,820', icon:'💻', color:'#eaf3de', text:'#2a5c12', link:'/jobs?domain=Engineering' },
  { name:'Product',     count:'980',   icon:'📦', color:'#faeeda', text:'#854f0b', link:'/jobs?domain=Product' },
  { name:'Data & AI',   count:'2,110', icon:'📊', color:'#fcebeb', text:'#a32d2d', link:'/jobs?domain=Data' },
  { name:'Marketing',   count:'760',   icon:'📣', color:'#f0e8fb', text:'#6b21a8', link:'/jobs?domain=Marketing' },
  { name:'Finance',     count:'540',   icon:'💰', color:'#e8f8fb', text:'#0e6e7c', link:'/jobs?domain=Finance' },
];

const TRENDING = ['Product Designer','Frontend Engineer','Data Scientist','DevOps Engineer','Growth Manager','ML Engineer'];

const FloatingCard = ({ logo, logoColor, logoText, title, company, badge, delay }) => (
  <div className="float-card" style={{ animationDelay: `${delay}s` }}>
    <div className="float-logo" style={{ background: logoColor, color: logoText }}>{logo}</div>
    <div>
      <div className="float-title">{title}</div>
      <div className="float-co">{company}</div>
    </div>
    <div className="float-badge">{badge}</div>
  </div>
);

const HomePage = () => {
  const [query, setQuery]         = useState('');
  const [location, setLocation]   = useState('');
  const [featured, setFeatured]   = useState([]);
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [activeJob, setActiveJob] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get('/jobs?featured=true&limit=4'),
      api.get('/companies?limit=8'),
    ]).then(([jobsRes, cosRes]) => {
      setFeatured(jobsRes.data.jobs || []);
      setCompanies(cosRes.data.companies || []);
    }).finally(() => setLoading(false));
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (query)    params.set('q', query);
    if (location) params.set('location', location);
    navigate(`/jobs?${params.toString()}`);
  };

  return (
    <div className="home">
      {/* HERO */}
      <section className="home-hero">
        <div className="hero-content">
          <div className="hero-eyebrow">Over 14,000 live listings worldwide</div>
          <h1>Find <em>meaningful</em> work<br/>that moves you forward.</h1>
          <p className="hero-sub">Connecting ambitious professionals with companies that value great talent. New roles added every day.</p>

          <form className="search-form" onSubmit={handleSearch}>
            <div className="sf-field">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Job title, skill, or company…" />
            </div>
            <div className="sf-divider" />
            <div className="sf-field">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <input value={location} onChange={e => setLocation(e.target.value)} placeholder="City or Remote" />
            </div>
            <button type="submit" className="sf-btn">Search Jobs</button>
          </form>

          <div className="hero-stats">
            {[['14,280','Live jobs'],['3,240','Companies'],['98k+','Placed this year'],['4.8★','Avg rating']].map(([v,l]) => (
              <div key={l} className="hero-stat"><strong>{v}</strong><span>{l}</span></div>
            ))}
          </div>
        </div>

        <div className="hero-visual">
          <FloatingCard logo="G" logoColor="#e8f0fb" logoText="#185fa5" title="Senior Designer" company="Google"  badge="Remote"  delay={0} />
          <FloatingCard logo="S" logoColor="#faeeda" logoText="#854f0b" title="Lead Engineer"   company="Stripe"  badge="₹90L+"  delay={1.2} />
          <FloatingCard logo="N" logoColor="#eaf3de" logoText="#2a5c12" title="PM — Growth"     company="Notion"  badge="New"    delay={2.4} />
        </div>
      </section>

      {/* TRENDING */}
      <div className="trending-bar">
        <span className="trending-label">Trending:</span>
        {TRENDING.map(t => <Link key={t} to={`/jobs?q=${encodeURIComponent(t)}`} className="trend-tag">{t}</Link>)}
      </div>

      {/* CATEGORIES */}
      <section className="home-section">
        <div className="section-header">
          <h2>Browse by category</h2>
          <Link to="/jobs" className="see-all">See all jobs →</Link>
        </div>
        <div className="categories-grid">
          {CATEGORIES.map(c => (
            <Link key={c.name} to={c.link} className="category-card">
              <div className="cat-icon" style={{ background: c.color, color: c.text }}>{c.icon}</div>
              <div className="cat-name">{c.name}</div>
              <div className="cat-count">{c.count} jobs</div>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED JOBS */}
      <section className="home-section home-alt">
        <div className="section-header">
          <h2>Featured opportunities</h2>
          <Link to="/jobs?featured=true" className="see-all">View all →</Link>
        </div>
        {loading ? <Spinner center /> : (
          <div className="featured-grid">
            {featured.map((j, i) => <JobCard key={j._id} job={j} onOpen={setActiveJob} delay={i * 0.06} />)}
          </div>
        )}
      </section>

      {/* HOW IT WORKS */}
      <section className="home-section">
        <div className="section-header"><h2>How WorkFlow works</h2></div>
        <div className="steps-grid">
          {[
            ['01','Create your profile','Upload your resume, set preferences, and let employers discover you.'],
            ['02','Discover matching jobs','Browse thousands of curated listings filtered to your skills.'],
            ['03','Apply in one click','Submit applications directly — right from the job listing.'],
            ['04','Get hired','Track your applications, receive offers, and start your next chapter.'],
          ].map(([n, t, d]) => (
            <div key={n} className="step-card">
              <div className="step-num">{n}</div>
              <h3>{t}</h3><p>{d}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* COMPANIES */}
      {companies.length > 0 && (
        <section className="home-section home-alt">
          <div className="section-header">
            <h2>Companies hiring now</h2>
            <Link to="/companies" className="see-all">All companies →</Link>
          </div>
          <div className="co-grid">
            {companies.map(c => (
              <Link key={c._id} to="/companies" className="co-card">
                <div className="co-card-logo" style={{ background: c.logoColor, color: c.logoText }}>{(c.name||'?')[0]}</div>
                <div className="co-card-name">{c.name}</div>
                <div className="co-card-industry">{c.industry}</div>
                <div className="co-card-jobs">★ {c.rating} · {c.openJobs || 0} open roles</div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="cta-section">
        <h2>Ready to find your next role?</h2>
        <p>Join 98,000+ professionals who found their dream job through WorkFlow.</p>
        <div style={{display:'flex',gap:12,justifyContent:'center',flexWrap:'wrap'}}>
          <Link to="/jobs" className="cta-btn-primary">Browse All Jobs</Link>
          <Link to="/post-job" className="cta-btn-secondary">Hire Talent</Link>
        </div>
      </section>

      <Footer />

      {activeJob && <JobDrawer job={activeJob} onClose={() => setActiveJob(null)} />}
    </div>
  );
};

export default HomePage;
